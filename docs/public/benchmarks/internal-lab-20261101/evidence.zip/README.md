# Spine internal lab evidence — 2026-11-01

Independently measured by the Spine project. WFB is a methodology reference, not a verifier of this run.

summary.json contains aggregate measurements. measurements.csv contains all 30 primary samples. raw/ contains the original zrk JSON reports, including HDR histograms. sources/ contains the measured application, dependency and observation-code snapshots.

Server budget: 3 vCPU / 3 GiB. HTTP/1.1 keep-alive, 256 connections, 43-byte JSON input. Three fresh starts per implementation; 15-second primary windows after stability-based warmup. Spine uses GOGC=400, GOMAXPROCS=3 and GOMEMLIMIT=2700MiB.

Application snapshots include their Dockerfiles and dependency locks. The archived observation scripts retain the original relative preparation-directory structure; they are audit inputs, not a standalone one-command runner. Adapt those paths and build image IDs before rerunning.

No cloud credentials, upload sessions, provider records or private host identifiers are included.
