#!/usr/bin/env python3
"""동일한 Linux VM 안에서 실행하는 Spine 로컬 비교 계측기."""
import argparse
import ctypes
import hashlib
import http.client
import io
import json
import os
from pathlib import Path
import random
import re
import shlex
import shutil
import socket
import statistics
import subprocess
import sys
import tarfile
import time
from datetime import datetime
from urllib.error import HTTPError
from urllib.request import Request, urlopen
import uuid
import zipfile
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
WFB = ROOT.parents[1] / "web-frameworks"
CASES = {"nethttp": ROOT / "nethttp", "echo": ROOT / "echo", "spine": WFB / "go/spine"}
SERVER_CPUS = "0-2"
LOAD_CPUS = "3-11"
SERVER_CORES, LOAD_CORES = 3, 9
ZRK_VERSION = "2.4.2"
LOAD_IMAGE = "spine-baseline-loadgen:local"


def call(args, log=None, check=True):
    if log:
        with Path(log).open("w") as stream:
            stream.write(shlex.join(map(str, args)) + "\n")
            stream.flush()
            return subprocess.run(list(map(str, args)), stdout=stream, stderr=subprocess.STDOUT, check=check)
    return subprocess.run(list(map(str, args)), capture_output=True, text=True, check=check)


def output(args):
    return call(args).stdout.strip()


def save(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def image(case):
    return f"spine-baseline-{case}:local"


def image_id(name):
    return output(["docker", "image", "inspect", name, "--format", "{{.Id}}"])


def input_hashes():
    files = {str(p.relative_to(ROOT)): digest(p) for case in ("nethttp", "echo")
             for p in CASES[case].glob("*") if p.suffix in (".go", ".mod", ".sum")}
    files["Dockerfile"] = digest(ROOT / "Dockerfile")
    receipt = json.loads((ROOT.parent / "receipt.json").read_text())
    for relative, expected in receipt["files"].items():
        actual = digest(WFB / relative)
        if actual != expected:
            raise RuntimeError(f"WFB 제출 소스가 준비 기록과 다릅니다: {relative}")
        files[relative] = actual
    return files


def build():
    (ROOT / "logs").mkdir(exist_ok=True)
    hashes = input_hashes()
    images = {}
    for case, context in CASES.items():
        print(f"빌드: {case}", flush=True)
        call(["docker", "build", "-f", ROOT / "Dockerfile", "-t", image(case), context], ROOT / f"logs/build-{case}.log")
        images[case] = image_id(image(case))
    save(ROOT / "build.json", {"sources": hashes, "images": images,
         "toolchain": "Go 1.27; CGO=1; trimpath; GOAMD64=v3 / GOARM64=v8.5"})
    print("비교 앱 3개 빌드 완료")


def verify_build():
    data = json.loads((ROOT / "build.json").read_text())
    if data["sources"] != input_hashes():
        raise RuntimeError("입력 소스가 바뀌었습니다. build를 다시 실행하세요.")
    for case, expected in data["images"].items():
        if image_id(image(case)) != expected:
            raise RuntimeError(f"빌드 이미지가 바뀌었습니다: {case}")
    return data


def start(case, run_id):
    name = f"spine-baseline-{run_id}-{case}"
    return output(["docker", "run", "-d", "--name", name, "--network", "host",
                   "--cpuset-cpus", SERVER_CPUS, "-e", f"GOMAXPROCS={SERVER_CORES}", image(case)])


def remove(cid):
    call(["docker", "rm", "-f", cid], check=False)


def contract(cid):
    for attempt in range(40):
        result = call(["docker", "exec", cid, "curl", "-fsS", "--max-time", "1", "http://127.0.0.1:3000/"], check=False)
        if result.returncode == 0:
            break
        time.sleep(0.25)
    else:
        raise RuntimeError("서버 시작 대기 시간이 초과됐습니다.")
    checks = [("GET", "/", ""), ("GET", "/user/0", "0"),
              ("GET", "/user/42", "42"), ("GET", "/user/alpha-7", "alpha-7"), ("POST", "/user", "")]
    for method, route, expected in checks:
        response = call(["docker", "exec", cid, "curl", "-sS", "--max-time", "2", "-X", method,
                         "-H", "Accept-Encoding: identity", "-w", "\n%{http_code}\n%{content_type}",
                         f"http://127.0.0.1:3000{route}"]).stdout
        body, status, content_type = response.rsplit("\n", 2)
        if status != "200" or body != expected or content_type.lower() != "text/plain; charset=utf-8":
            raise RuntimeError(f"응답 계약 불일치: {method} {route}: {status}, {body!r}, {content_type}")
    return len(checks)


def check():
    verify_build()
    result = {}
    for case in CASES:
        cid = start(case, uuid.uuid4().hex[:8])
        try:
            result[case] = {"passed": contract(cid)}
            print(f"{case}: 응답 계약 5개 통과", flush=True)
        finally:
            remove(cid)
    save(ROOT / "contract-check.json", result)


def check_native():
    # 네트워크 장애 중에는 캐시된 호스트 Go로 기능만 검증합니다. 성능 수치를 만들지 않습니다.
    hashes = input_hashes()
    (ROOT / "bin").mkdir(exist_ok=True)
    (ROOT / "logs").mkdir(exist_ok=True)
    checks = [("GET", "/", ""), ("GET", "/user/0", "0"),
              ("GET", "/user/42", "42"), ("GET", "/user/alpha-7", "alpha-7"), ("POST", "/user", "")]
    evidence = {"scope":"native HTTP contract only; not Linux container or performance validation",
                "go":output(["go", "version"]),"sources":hashes,"cases":{}}
    for case, source in CASES.items():
        binary = ROOT / "bin" / case
        with (ROOT / f"logs/build-native-{case}.log").open("w") as log:
            subprocess.run(["go", "build", "-mod=readonly", "-trimpath", "-o", str(binary), "."],
                           cwd=source, env=os.environ | {"GOPROXY":"off"}, stdout=log, stderr=subprocess.STDOUT, check=True)
        try:
            with socket.create_connection(("127.0.0.1", 3000), timeout=.2):
                raise RuntimeError("호스트 3000번 포트가 사용 중입니다. 다른 프로세스는 종료하지 않습니다.")
        except (ConnectionRefusedError, socket.timeout):
            pass
        with (ROOT / f"logs/native-{case}.log").open("w") as log:
            process = subprocess.Popen([str(binary)], cwd=source, env=os.environ | {"SPINE_PORT":"3000"}, stdout=log, stderr=subprocess.STDOUT)
            try:
                for attempt in range(40):
                    if process.poll() is not None:
                        raise RuntimeError(f"{case} 앱이 시작 중 종료됐습니다.")
                    try:
                        with socket.create_connection(("127.0.0.1", 3000), timeout=.2):
                            break
                    except (ConnectionRefusedError, socket.timeout):
                        time.sleep(.1)
                else:
                    raise RuntimeError(f"{case} 앱의 시작 시간이 초과됐습니다.")
                for method, route, expected in checks:
                    client = http.client.HTTPConnection("127.0.0.1", 3000, timeout=2)
                    try:
                        client.request(method, route, headers={"Accept-Encoding":"identity"})
                        response = client.getresponse()
                        body = response.read().decode()
                        content_type = response.getheader("Content-Type", "").lower()
                        if response.status != 200 or body != expected or content_type != "text/plain; charset=utf-8":
                            raise RuntimeError(f"{case}: {method} {route} 응답 계약 불일치")
                    finally:
                        client.close()
                evidence["cases"][case] = {"passed":len(checks),"binary_sha256":digest(binary)}
                print(f"{case}: 호스트 HTTP 계약 5개 통과", flush=True)
            finally:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait()
    save(ROOT / "native-contract-check.json", evidence)


def download(url):
    with urlopen(Request(url, headers={"User-Agent": "spine-baseline"}), timeout=20) as response:
        return response.read()


def loadgen(binary=None):
    verify_build()
    tools = ROOT / "tools"
    tools.mkdir(exist_ok=True)
    origin = {"requested_version": ZRK_VERSION}
    if binary:
        data = Path(binary).read_bytes()
        origin["source"] = str(Path(binary).resolve())
    else:
        for tag in (f"v{ZRK_VERSION}", ZRK_VERSION):
            try:
                release = json.loads(download(f"https://api.github.com/repos/zoxy-io/zrk/releases/tags/{tag}"))
                break
            except HTTPError as error:
                if error.code != 404:
                    raise
        else:
            raise RuntimeError("요청한 zrk 릴리스를 찾지 못했습니다. Linux 바이너리를 --binary로 지정하세요.")
        arch = output(["docker", "info", "--format", "{{.Architecture}}"])
        pattern = r"aarch64|arm64" if arch in ("aarch64", "arm64") else r"x86_64|amd64"
        assets = [a for a in release.get("assets", []) if "linux" in a["name"].lower()
                  and re.search(pattern, a["name"], re.I) and not re.search(r"sha|checksum|\.sig$", a["name"], re.I)]
        if len(assets) != 1:
            raise RuntimeError(f"릴리스 바이너리를 하나로 결정할 수 없습니다: {[a['name'] for a in assets]}. --binary를 지정하세요.")
        asset = assets[0]
        archive = download(asset["browser_download_url"])
        expected = asset.get("digest")
        if expected and expected != "sha256:" + hashlib.sha256(archive).hexdigest():
            raise RuntimeError("릴리스 파일 해시가 일치하지 않습니다.")
        origin.update({"source": asset["browser_download_url"], "archive_sha256": hashlib.sha256(archive).hexdigest()})
        data = archive
        stream = io.BytesIO(archive)
        if tarfile.is_tarfile(stream):
            stream.seek(0)
            with tarfile.open(fileobj=stream) as tar:
                members = [m for m in tar.getmembers() if m.isfile() and Path(m.name).name == "zrk"]
                if len(members) != 1:
                    raise RuntimeError("압축 파일에서 zrk 실행 파일을 하나로 결정하지 못했습니다.")
                data = tar.extractfile(members[0]).read()
        elif zipfile.is_zipfile(io.BytesIO(archive)):
            with zipfile.ZipFile(io.BytesIO(archive)) as zipped:
                members = [m for m in zipped.namelist() if Path(m).name == "zrk"]
                if len(members) != 1:
                    raise RuntimeError("압축 파일에서 zrk 실행 파일을 하나로 결정하지 못했습니다.")
                data = zipped.read(members[0])
    (tools / "zrk").write_bytes(data)
    shutil.copyfile(ROOT / "user_id.lua", tools / "user_id.lua")
    call(["docker", "build", "-f", ROOT / "Loadgen.Dockerfile", "-t", LOAD_IMAGE, tools], ROOT / "logs/build-loadgen.log")
    version = output(["docker", "run", "--rm", "--entrypoint", "zrk", LOAD_IMAGE, "--version"])
    if not re.search(rf"\b{re.escape(ZRK_VERSION)}\b", version):
        raise RuntimeError(f"zrk 버전이 고정 버전과 다릅니다: {version}")
    origin.update({"version_output": version, "binary_sha256": hashlib.sha256(data).hexdigest(), "image": image_id(LOAD_IMAGE)})
    save(ROOT / "loadgen.json", origin)
    print(version)


def host_cpu_busy():
    # top의 프로세스 전수 조사가 유휴 측정에 영향을 주지 않도록 OS 누적 카운터만 읽습니다.
    lib = ctypes.CDLL('/usr/lib/libSystem.B.dylib')
    lib.mach_host_self.restype = ctypes.c_uint
    lib.host_statistics.argtypes = [ctypes.c_uint, ctypes.c_int, ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_uint)]
    lib.mach_port_deallocate.argtypes = [ctypes.c_uint, ctypes.c_uint]
    port = lib.mach_host_self()
    def ticks():
        values = (ctypes.c_int * 4)()
        count = ctypes.c_uint(4)
        if lib.host_statistics(port, 3, values, ctypes.byref(count)) != 0:
            raise RuntimeError('호스트 CPU 누적 카운터를 읽지 못했습니다.')
        return [ctypes.c_uint(value).value for value in values]
    try:
        before = ticks()
        time.sleep(1)
        after = ticks()
        delta = [(b-a) % (2**32) for a,b in zip(before,after)]
        return 100 * (1-delta[2]/sum(delta)) if sum(delta) else None
    finally:
        lib.mach_port_deallocate(ctypes.c_uint.in_dll(lib, 'mach_task_self_').value, port)


def host_status(cpu=True, allow_battery=False):
    power = output(["pmset", "-g", "batt"])
    containers = output(["docker", "ps", "--format", "{{.Names}} {{.Image}}"])
    data = {"power": power, "battery_explicitly_allowed": allow_battery,
            "containers": containers, "thermal": output(["pmset", "-g", "therm"])}
    data["blockers"] = []
    if "AC Power" not in power and not allow_battery:
        data["blockers"].append("외부 전원이 연결되어 있지 않습니다.")
    if containers:
        data["blockers"].append("다른 Docker 컨테이너가 실행 중입니다. 자동 종료하지 않습니다.")
    if cpu:
        data["cpu_busy_percent"] = host_cpu_busy()
        data["cpu_sample_source"] = "Mach HOST_CPU_LOAD_INFO; one-second delta"
        if data["cpu_busy_percent"] is None or data["cpu_busy_percent"] > 5:
            data["blockers"].append("호스트 CPU 사용률이 5%를 넘거나 측정되지 않았습니다.")
    return data


def cpu_counter(cid):
    text = output(["docker", "exec", cid, "cat", "/sys/fs/cgroup/cpu.stat"])
    return int(re.search(r"^usage_usec\s+(\d+)$", text, re.M).group(1))


def execute_zrk(cid, filename, method, route, concurrency, duration, threads, log):
    # 각 요청의 인자를 새로 만들어 GET용 Lua가 POST에 남지 않게 합니다.
    args = ["docker", "exec", cid, "zrk", "--plain", "--closed", "-t", threads,
            "--connections", concurrency, "--duration", f"{duration}s", "--method", method,
            "--timeout", "8s", "--format", "json", "--output", f"/results/{filename}", "-H", "Accept-Encoding:identity"]
    if route == "/user/42":
        args += ["--script", "/opt/user_id.lua"]
    args.append(f"http://127.0.0.1:3000{route}")
    call(args, log)


def run(args):
    built = verify_build()
    installed = json.loads((ROOT / "loadgen.json").read_text())
    if image_id(LOAD_IMAGE) != installed["image"]:
        raise RuntimeError("부하 도구 이미지가 설치 기록과 다릅니다.")
    # 다른 세션의 완료 여부는 사용자 확인 사항이며, 앱을 종료하거나 작업을 중단하지 않습니다.
    samples = []
    observations = []
    deadline = time.monotonic() + 180 + args.quiet_seconds
    status = host_status(cpu=False, allow_battery=args.allow_battery)
    while True:
        if status["containers"] or ("AC Power" not in status["power"] and not args.allow_battery):
            raise RuntimeError(" / ".join(status["blockers"]))
        busy = host_cpu_busy()
        if busy is None:
            raise RuntimeError("CPU 부하를 측정하지 못했습니다.")
        samples.append(busy)
        observations.append(busy)
        samples = samples[-args.quiet_seconds:]
        if len(samples) == args.quiet_seconds and statistics.mean(samples) <= 5 and max(samples) <= 10:
            status.update({"cpu_window_busy_percent":samples,"cpu_mean_busy_percent":statistics.mean(samples),
                           "cpu_max_busy_percent":max(samples),"all_cpu_observations":observations,
                           "cpu_sample_source":"Mach HOST_CPU_LOAD_INFO; one-second deltas",
                           "cpu_idle_policy":"window mean <=5%; each sample <=10%"})
            break
        if time.monotonic() > deadline:
            raise RuntimeError("CPU 안정 대기 시간이 초과됐습니다.")
        if len(observations) % 10 == 0:
            print(f"CPU 유휴 관측 {len(observations)}회: 최근 평균 {statistics.mean(samples):.2f}%", flush=True)
            status = host_status(cpu=False, allow_battery=args.allow_battery)
    stamp = datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y%m%d-%H%M%S")
    run_id = uuid.uuid4().hex[:8]
    results = ROOT / "results" / f"{stamp}-{run_id}"
    results.mkdir(parents=True, exist_ok=False)
    routes = [("GET", "/")]
    if args.all_routes:
        routes += [("GET", "/user/42"), ("POST", "/user")]
    manifest = {"build": built, "loadgen": installed, "server_cpus": SERVER_CPUS, "load_cpus": LOAD_CPUS,
                "repetitions": args.repetitions, "duration_seconds": args.duration, "warmup_seconds": 5,
                "concurrencies": [64, 256, 512], "routes": routes, "seed": 20261031,
                "battery_explicitly_allowed": args.allow_battery,
                "preflight": status, "runner_sha256": digest(__file__), "state": "running",
                "scope": "local Linux Docker VM; not a WFB published score",
                "host_hardware": output(["sysctl", "-n", "hw.model", "hw.ncpu", "hw.memsize"]),
                "docker_resources": output(["docker", "info", "--format", "{{.NCPU}} CPUs; {{.MemTotal}} bytes; {{.Architecture}}"])}
    save(results / "manifest.json", manifest)
    loader = output(["docker", "run", "-d", "--name", f"spine-baseline-{run_id}-load", "--network", "host",
                     "--cpuset-cpus", LOAD_CPUS, "-v", f"{results}:/results", LOAD_IMAGE])
    rows = []
    rng = random.Random(20261031)
    try:
        for repetition in range(args.repetitions):
            order = list(CASES)
            rng.shuffle(order)
            for case in order:
                cid = start(case, run_id)
                try:
                    contract(cid)
                    prefix = f"r{repetition+1}-{case}"
                    execute_zrk(loader, prefix + "-warmup.json", "GET", "/", 50, 5, LOAD_CORES, results / f"{prefix}-warmup.log")
                    for method, route in routes:
                        for concurrency in (64, 256, 512):
                            name = f"{prefix}-{method}-{route.strip('/').replace('/', '_') or 'root'}-c{concurrency}"
                            before_server, before_load = cpu_counter(cid), cpu_counter(loader)
                            started = time.monotonic()
                            execute_zrk(loader, name + ".json", method, route, concurrency, args.duration, LOAD_CORES, results / f"{name}.log")
                            after_server, after_load = cpu_counter(cid), cpu_counter(loader)
                            wall = time.monotonic() - started
                            raw = json.loads((results / f"{name}.json").read_text())
                            errors = raw["errors"]
                            required = ("connect", "read", "write", "timeout", "non_2xx_3xx")
                            error_count = sum(errors[k] for k in required)
                            saturation = (after_server - before_server) / 1e6 / wall / SERVER_CORES
                            load_saturation = (after_load - before_load) / 1e6 / wall / LOAD_CORES
                            rps = raw["requests"] / raw["duration_s"]
                            valid = raw["config"]["closed"] is True and error_count == 0 and saturation >= .75 and load_saturation < .9
                            row = {"round": repetition+1, "case": case, "method": method, "route": route, "concurrency": concurrency,
                                   "rps": rps, "p99_ms": raw["latency_us"]["p99"] / 1000, "errors": error_count,
                                   "server_cpu_saturation": saturation, "load_cpu_saturation": load_saturation,
                                   "valid_server_bound_comparison": valid, "raw": name + ".json"}
                            rows.append(row)
                            save(results / "rows.json", rows)
                            print(json.dumps(row, ensure_ascii=False), flush=True)
                finally:
                    remove(cid)
        summary = []
        for case in CASES:
            for method, route in routes:
                for concurrency in (64, 256, 512):
                    group = [r for r in rows if (r["case"],r["method"],r["route"],r["concurrency"]) == (case,method,route,concurrency)]
                    rates = [r["rps"] for r in group]
                    median = statistics.median(rates)
                    summary.append({"case":case,"method":method,"route":route,"concurrency":concurrency,
                                    "median_rps":median,"min_rps":min(rates),"max_rps":max(rates),
                                    "median_p99_ms":statistics.median(r["p99_ms"] for r in group),
                                    "all_repetitions_valid":len(group)==args.repetitions and all(r["valid_server_bound_comparison"] for r in group)})
        for item in summary:
            current = [r for r in rows if (r["case"],r["method"],r["route"],r["concurrency"]) ==
                       (item["case"],item["method"],item["route"],item["concurrency"])]
            for reference in ("nethttp", "echo"):
                peers = {r["round"]:r for r in rows if (r["case"],r["method"],r["route"],r["concurrency"]) ==
                         (reference,item["method"],item["route"],item["concurrency"])}
                accepted = item["all_repetitions_valid"] and len(peers)==args.repetitions and all(r["valid_server_bound_comparison"] for r in peers.values())
                item[f"median_paired_rps_ratio_vs_{reference}"] = statistics.median(r["rps"]/peers[r["round"]]["rps"] for r in current) if accepted else None
        save(results / "summary.json", summary)
        manifest["state"] = "complete"
    except BaseException as error:
        manifest.update({"state":"interrupted_or_failed", "error":str(error)})
        raise
    finally:
        remove(loader)
        manifest["power_at_end"] = output(["pmset", "-g", "batt"])
        manifest["thermal_at_end"] = output(["pmset", "-g", "therm"])
        save(results / "manifest.json", manifest)
    print(f"결과: {results}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="command", required=True)
    subs.add_parser("build")
    subs.add_parser("check")
    subs.add_parser("check-native")
    subs.add_parser("status")
    install = subs.add_parser("loadgen")
    install.add_argument("--binary", type=Path)
    measure = subs.add_parser("run")
    measure.add_argument("--repetitions", type=int, default=5)
    measure.add_argument("--duration", type=int, default=15)
    measure.add_argument("--quiet-seconds", type=int, default=30)
    measure.add_argument("--all-routes", action="store_true")
    measure.add_argument("--allow-battery", action="store_true", help="사용자가 배터리 구동을 명시적으로 허용했을 때만 사용")
    args = parser.parse_args()
    if args.command == "build": build()
    elif args.command == "check": check()
    elif args.command == "check-native": check_native()
    elif args.command == "loadgen": loadgen(args.binary)
    elif args.command == "status":
        data = host_status()
        save(ROOT / "last-preflight.json", data)
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 2 if data["blockers"] else 0
    else:
        if min(args.repetitions, args.duration, args.quiet_seconds) <= 0:
            raise RuntimeError("반복 횟수, 계측 시간과 대기 시간은 양수여야 합니다.")
        run(args)
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, KeyError, RuntimeError, subprocess.CalledProcessError) as error:
        print(f"중단: {error}", file=sys.stderr)
        sys.exit(1)
