#!/usr/bin/env python3
"""비교 준비와 실제 계측을 명령으로 분리한 자체 벤치마크 실행기."""
import argparse
import collections
import ctypes
import hashlib
import http.client
import json
import math
import random
import re
import statistics
import subprocess
import time
import uuid
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent
PROTOCOL = ROOT / "protocol.json"
P = json.loads(PROTOCOL.read_text())


def call(args, check=True):
    return subprocess.run(list(map(str, args)), capture_output=True, text=True, check=check)


def output(args):
    return call(args).stdout.strip()


def save(path, data):
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    temp.replace(path)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(ZoneInfo("Asia/Seoul")).isoformat()


def sources():
    files = [PROTOCOL, ROOT / "bench.py", ROOT / "prepare.py", ROOT / "Loadgen.Dockerfile", ROOT / ".dockerignore", ROOT / "base-images.lock.json", ROOT / "payload.json", ROOT / "cloud_assets.py", ROOT / "install_buildx.py"]
    for folder in ("apps", "scripts"):
        files.extend(p for p in (ROOT / folder).rglob("*") if p.is_file()
                     and not any(x in {"node_modules", "target", "__pycache__", ".git", "bin"} for x in p.parts))
    return {str(p.relative_to(ROOT)): sha(p) for p in sorted(files)}


def inspect(image):
    return json.loads(output(["docker", "image", "inspect", image]))[0]


def images():
    result = {}
    for image in sorted({c["image"] for c in P["cases"]} | {P["load_image"]}):
        i = inspect(image)
        if (i["Os"], i["Architecture"]) != ("linux", "amd64"):
            raise RuntimeError("이미지 아키텍처 불일치: " + image)
        result[image] = i["Id"]
    return result


def schedule():
    rng = random.Random(P["seed"])
    result = []
    for repetition in range(1, P["repetitions"] + 1):
        order = list(P["cases"])
        rng.shuffle(order)
        for case in order:
            cells = [(w["id"], c) for w in P["workloads"] for c in P["concurrencies"]]
            rng.shuffle(cells)
            result.append({"round": repetition, "case": case["id"], "cells": cells})
    return result


def plan():
    jobs = schedule()
    rows = sum(len(j["cells"]) for j in jobs)
    return {"performance_started": False, "rows": rows, "server_starts": len(jobs),
            "minimum_minutes": (rows * P["duration_seconds"] + len(jobs) *
                                (P["warmup_minimum_seconds"] + P["cooldown_seconds"])) / 60,
            "maximum_minutes_without_startup": (rows * P["duration_seconds"] + len(jobs) *
                                                P["warmup_retry_attempts"] *
                                                (P["warmup_maximum_seconds"] + P["cooldown_seconds"])) / 60,
            "schedule": jobs}


def stop(cid):
    call(["docker", "rm", "-f", cid], check=False)


def start(case, run_id, functional=False):
    args = ["docker", "run", "-d", "--name", f"spine-compare-{run_id}-{case['id']}",
            "--cpuset-cpus", P["server_cpus"], "--cpus", str(P["server_cores"]),
            "--memory", P["server_memory"], "--memory-swap", P["server_memory"],
            "--ulimit", "nofile=65535:65535"]
    args += ["-p", "127.0.0.1::3000"] if functional else ["--network", "host"]
    for key, value in case["environment"].items():
        args += ["-e", key + "=" + value]
    return output(args + [case["image"]])


def contract(cid, loader=None):
    info = json.loads(output(["docker", "inspect", cid]))[0]
    ports = info["NetworkSettings"]["Ports"].get("3000/tcp")
    if ports:
        from scripts.http_contract import check_http
        return check_http(port=int(ports[0]["HostPort"]))
    if loader is None:
        raise RuntimeError("VM 내부 HTTP 검사에 부하 도구 컨테이너가 필요합니다.")
    return json.loads(output(["docker", "exec", loader, "python3", "/opt/http_contract.py"]))


def check():
    result = {"at": now(), "performance_measured": False, "cases": {}, "sources": sources(), "images": images()}
    for case in P["cases"]:
        cid = start(case, uuid.uuid4().hex[:8], functional=True)
        try:
            checks = contract(cid)
            result["cases"][case["id"]] = {"passed": len(checks), "checks": checks}
            print(case["id"], len(checks), "HTTP 계약 통과", flush=True)
        except Exception:
            result["failed_case"] = case["id"]
            result["failed_log"] = call(["docker", "logs", cid], check=False).stdout
            save(ROOT / "logs/contract-check.json", result)
            raise
        finally:
            stop(cid)
    result["complete"] = True
    save(ROOT / "logs/contract-check.json", result)


def seal():
    checked = json.loads((ROOT / "logs/contract-check.json").read_text())
    current = sources()
    current_images = images()
    if not checked.get("complete") or checked["sources"] != current or checked["images"] != current_images:
        raise RuntimeError("현재 소스와 이미지로 HTTP 계약 검사를 다시 실행해야 합니다.")
    if sha(ROOT / "scripts/zrk") != P["load_binary_sha256"]:
        raise RuntimeError("부하 도구 바이너리 해시 불일치")
    save(ROOT / "ready.json", {"at": now(), "state": "prepared_not_measured", "performance_started": False,
                               "sources": current, "images": current_images,
                               "contract_sha256": sha(ROOT / "logs/contract-check.json"), "plan": plan()})
    print("준비 완료: 성능 측정은 시작하지 않았습니다.")


def verify():
    ready = json.loads((ROOT / "ready.json").read_text())
    if ready["sources"] != sources() or ready["images"] != images():
        raise RuntimeError("준비 이후 소스 또는 이미지가 바뀌었습니다.")
    if ready["contract_sha256"] != sha(ROOT / "logs/contract-check.json"):
        raise RuntimeError("HTTP 계약 검사 기록이 바뀌었습니다.")
    return ready


def host_busy():
    def ticks():
        values = [int(x) for x in Path("/proc/stat").read_text().splitlines()[0].split()[1:9]]
        return sum(values), values[3] + values[4]
    first = ticks()
    time.sleep(1)
    last = ticks()
    return 100 * (1 - (last[1]-first[1])/(last[0]-first[0]))


def power_status():
    return "cloud VM; provider-managed power"


def preflight(allow_battery):
    verify()
    if output(["docker", "ps", "-q"]):
        raise RuntimeError("다른 컨테이너가 실행 중입니다.")
    info = json.loads(output(["docker", "info", "--format", "{{json .}}"])); samples = []
    if info["NCPU"] < 12 or info["MemTotal"] < 6 * 1024**3:
        raise RuntimeError("최소 12 vCPU와 6 GiB가 필요합니다.")
    for _ in range(210):
        samples.append(host_busy()); window = samples[-P["idle_window_seconds"]:]
        if len(window) == P["idle_window_seconds"] and statistics.mean(window) <= P["idle_mean_limit_percent"] and max(window) <= P["idle_sample_limit_percent"]:
            return {"power": power_status(), "docker": {k: info[k] for k in ["NCPU", "MemTotal", "Architecture", "KernelVersion", "ServerVersion"]},
                    "cpu_observations_percent": samples, "thermal": "not exposed by provider",
                    "hardware": output(["lscpu"]), "memory": Path("/proc/meminfo").read_text(),
                    "cpu_steal_time_start": Path("/proc/stat").read_text().splitlines()[0]}
    raise RuntimeError("호스트 CPU가 안정되지 않았습니다.")


def counter(cid):
    raw = output(["docker", "exec", cid, "cat", "/sys/fs/cgroup/cpu.stat"])
    return int(re.search(r"^usage_usec\s+(\d+)$", raw, re.M).group(1))


def memory(cid):
    values = output(["docker", "exec", cid, "cat", "/sys/fs/cgroup/memory.events"])
    peak = call(["docker", "exec", cid, "cat", "/sys/fs/cgroup/memory.peak"], check=False)
    source = "memory.peak" if peak.returncode == 0 else "memory.current"
    size = int(peak.stdout.strip()) if peak.returncode == 0 else int(output(["docker", "exec", cid, "cat", "/sys/fs/cgroup/memory.current"]))
    return {"events": {key: int(value) for key, value in (line.split() for line in values.splitlines())},
            "observed_bytes": size, "measurement_source": source}


def raw_valid(raw, concurrency, duration):
    config = raw["config"]
    return (raw["zrk_version"] == P["load_tool_version"] and config["closed"]
            and not config["disable_keepalive"] and config["connections"] == concurrency
            and config["launched"] == concurrency and config["duration_s"] == duration
            and raw["requests"] > 0 and raw["duration_s"] > 0
            and not sum(raw["errors"].values())
            and not sum(value for key, value in raw["status_codes"].items() if key != "2xx")
            and raw["status_codes"]["2xx"] == raw["requests"])


def load(loader, folder, name, workload, concurrency, duration):
    args = ["docker", "exec", loader, "zrk", "--plain", "--closed", "-t", str(P["load_cores"]),
            "--connections", str(concurrency), "--duration", f"{duration}s", "--method", workload["method"],
            "--timeout", "8s", "--format", "json", "--output", f"/results/{name}.json", "-H", "Accept-Encoding:identity"]
    if workload["body_file"]:
        args += ["--body", "@/opt/" + workload["body_file"], "-H", "Content-Type:application/json"]
    args += ["http://127.0.0.1:3000" + workload["path"]]
    result = call(args, check=False)
    (folder / (name + ".log")).write_text(json.dumps(args) + "\n" + result.stdout + result.stderr)
    if result.returncode:
        raise RuntimeError("부하 도구 실행 실패: " + name)
    return json.loads((folder / (name + ".json")).read_text())


class WarmupRetryQueue:
    """최초 순서는 유지하고, 예열 실패 항목을 뒤로 보내 제한 횟수만 재시도합니다."""

    def __init__(self, jobs, max_attempts):
        if max_attempts < 1:
            raise ValueError("최대 시도 횟수는 1 이상이어야 합니다.")
        self.pending = [(job, 1) for job in jobs]
        self.max_attempts = max_attempts
        self.exhausted = []
        self.deferred = set()

    def __iter__(self):
        return iter(self.pending)

    def defer(self, job, attempt):
        key = (job["round"], job["case"], attempt)
        if key in self.deferred:
            raise ValueError("같은 실패 시도가 중복 등록됐습니다.")
        self.deferred.add(key)
        if attempt < self.max_attempts:
            self.pending.append((job, attempt + 1))
        else:
            self.exhausted.append({"round": job["round"], "case": job["case"]})


def warmup(loader, folder, prefix):
    values = collections.defaultdict(list)
    windows = []
    elapsed = 0
    record = {"elapsed_seconds": 0, "windows": windows, "last_three_cv": {}, "stable": False}
    while elapsed + P["warmup_window_seconds"] <= P["warmup_maximum_seconds"]:
        workload = P["workloads"][len(windows) % len(P["workloads"])]
        name = f"{prefix}-warmup-{len(windows)+1}"
        raw = None
        try:
            raw = load(loader, folder, name, workload, 256, P["warmup_window_seconds"])
            if not raw_valid(raw, 256, P["warmup_window_seconds"]):
                raise RuntimeError("예열 중 요청 또는 설정 오류 발생")
        except Exception as error:
            # 실패한 창을 안정도 계산에 섞지 않고, 새 서버로 재시도할 근거를 보존합니다.
            record.update({"stable": False, "failure_kind": "warmup_error", "failed_at": now(),
                           "failed_workload": workload["id"], "failed_window": name,
                           "error_type": type(error).__name__, "error": str(error)})
            if isinstance(raw, dict):
                record["failed_raw_diagnostics"] = {key: raw.get(key) for key in
                    ("requests", "duration_s", "errors", "status_codes", "config")}
            save(folder / (prefix + "-warmup-state.json"), record)
            print(json.dumps({"stage": "warmup_error", "prefix": prefix, **record}, ensure_ascii=False), flush=True)
            return record
        values[workload["id"]].append(raw["requests"] / raw["duration_s"])
        windows.append({"workload": workload["id"], "rps": values[workload["id"]][-1]})
        elapsed += P["warmup_window_seconds"]
        print(json.dumps({"stage":"warmup_window","prefix":prefix,"elapsed_seconds":elapsed,"workload":workload["id"]}),flush=True)
        if elapsed >= P["warmup_minimum_seconds"] and len(windows) % len(P["workloads"]) == 0:
            cv = {w["id"]: statistics.stdev(values[w["id"]][-3:]) / statistics.mean(values[w["id"]][-3:]) for w in P["workloads"]}
            record["last_three_cv"] = cv
            record["stable"] = all(v <= P["warmup_cv_limit"] for v in cv.values())
        record["elapsed_seconds"] = elapsed
        save(folder / (prefix + "-warmup-state.json"), record)
        if record["stable"]:
            return record
    return record


def summarize(rows):
    result = []
    for case in P["cases"]:
        for workload in P["workloads"]:
            for concurrency in P["concurrencies"]:
                group = [r for r in rows if (r["case"], r["workload"], r["concurrency"]) == (case["id"], workload["id"], concurrency)]
                if not group:
                    continue
                rates = [r["rps"] for r in group]
                item = {"case": case["id"], "workload": workload["id"], "concurrency": concurrency,
                        "median_rps": statistics.median(rates), "min_rps": min(rates), "max_rps": max(rates),
                        "median_p99_ms": statistics.median(r["p99_ms"] for r in group),
                        "errors": sum(r["errors"] for r in group), "rounds": [r["round"] for r in group],
                        "all_valid": len(group) == P["repetitions"] and all(r["valid"] for r in group)}
                if case["id"] != "spine":
                    spine = {r["round"]: r for r in rows if (r["case"], r["workload"], r["concurrency"]) == ("spine", workload["id"], concurrency)}
                    ratios = [spine[r["round"]]["rps"] / r["rps"] for r in group if r["round"] in spine]
                    item["paired_spine_ratios"] = ratios
                    item["median_spine_ratio"] = statistics.median(ratios) if ratios else None
                    item["paired_complete"] = len(ratios) == P["repetitions"]
                result.append(item)
    return result


def audit(folder):
    manifest = json.loads((folder / "manifest.json").read_text())
    rows = json.loads((folder / "rows.json").read_text())
    expected = {(j["round"], j["case"], w, c) for j in schedule() for w, c in j["cells"]}
    actual = [(r["round"], r["case"], r["workload"], r["concurrency"]) for r in rows]
    failures = []
    if manifest["protocol"] != P or manifest["schedule"] != json.loads(json.dumps(schedule())):
        failures.append("사전에 정한 프로토콜 또는 실행 순서가 다릅니다.")
    if len(actual) != len(set(actual)) or set(actual) != expected:
        failures.append("측정 행이 누락되거나 중복됐습니다.")
    for row in rows:
        raw = json.loads((folder / row["raw"]).read_text())
        if not math.isclose(row["rps"], raw["requests"] / raw["duration_s"], rel_tol=1e-12):
            failures.append("RPS 불일치: " + row["raw"])
        expected_workload = next(w for w in P["workloads"] if w["id"] == row["workload"])
        if (not raw_valid(raw, row["concurrency"], P["duration_seconds"])
                or raw["target"]["method"] != expected_workload["method"]
                or raw["target"]["url"] != "http://127.0.0.1:3000" + expected_workload["path"]
                or not row["valid"] or row["load_cpu_fraction"] >= P["max_load_cpu_fraction"]
                or row["memory"]["events"].get("oom_kill", 0) or row["oom_killed"]):
            failures.append("측정 유효 조건 불충족: " + row["raw"])
        if (not math.isclose(row["p99_ms"], raw["latency_us"]["p99"] / 1000)
                or row["errors"] != sum(raw["errors"].values())):
            failures.append("요약 지연 또는 오류 카운터 불일치: " + row["raw"])
    if len(manifest.get("warmups", [])) != len(manifest["schedule"]):
        failures.append("예열 기록이 완전하지 않습니다.")
    for warm in manifest.get("warmups", []):
        if (not warm.get("stable") or warm["elapsed_seconds"] < P["warmup_minimum_seconds"]
                or any(v > P["warmup_cv_limit"] for v in warm["last_three_cv"].values())):
            failures.append("예열 안정 조건을 통과하지 못했습니다.")
    if len(manifest.get("post_contracts", [])) != len(manifest["schedule"]):
        failures.append("측정 후 HTTP 계약 검사 기록이 완전하지 않습니다.")
    if not manifest.get("sources_and_images_unchanged_at_end"):
        failures.append("측정 종료 시 소스와 이미지의 일치를 확인하지 못했습니다.")
    if manifest.get("state") != "completed":
        failures.append("실행이 완료 상태가 아닙니다.")
    if manifest.get("exhausted_jobs"):
        failures.append("재시도 후에도 예열에 실패한 항목이 있습니다.")
    report = {"at": now(), "publishable": not failures, "failures": failures,
              "expected_rows": len(expected), "actual_rows": len(rows)}
    save(folder / "audit.json", report)
    save(folder / "summary.json", summarize(rows))
    lines = ["# 자체 HTTP 벤치마크", "", "공개 WFB 공식 점수가 아닌 자체 측정입니다.", "",
             "문서용 비교 가능: " + ("예" if report["publishable"] else "아니오"), "",
             "| 구현 | 작업 | 동시접속 | 중앙값 req/s | 최소~최대 req/s | p99 중앙값 ms | Spine 대응 배수 |", "|---|---|---:|---:|---:|---:|---:|"]
    for item in summarize(rows):
        ratio = item.get("median_spine_ratio")
        lines.append(f"| {item['case']} | {item['workload']} | {item['concurrency']} | {item['median_rps']:,.0f} | {item['min_rps']:,.0f}~{item['max_rps']:,.0f} | {item['median_p99_ms']:.3f} | {ratio:.3f} |" if ratio is not None else f"| {item['case']} | {item['workload']} | {item['concurrency']} | {item['median_rps']:,.0f} | {item['min_rps']:,.0f}~{item['max_rps']:,.0f} | {item['median_p99_ms']:.3f} | — |")
    lines += ["", "배수는 같은 서버 재시작 회차의 Spine/상대 처리량 비율 중앙값입니다.",
              "p99는 포화된 closed-loop 지연이며 같은 고정 도착률에서의 지연 비교가 아닙니다.",
              "JSON 검증은 Spine 명시적 검사, Nest class-validator, Spring Jakarta Validation, FastAPI Pydantic을 사용합니다.",
              "DB, TLS, 인증, 외부 I/O와 실제 업무 API 성능으로 일반화하지 않습니다."]
    lines += ["", "예열 실패 시도 수: " + str(len(manifest.get("warmup_failures", []))),
              "모든 실패 시도의 원시 예열 자료를 보존하며, 성공한 예열 뒤의 본 측정만 요약합니다."]
    if failures:
        lines += ["", "검증 실패:"] + ["- " + f for f in failures]
    (folder / "REPORT.md").write_text("\n".join(lines) + "\n")
    save(folder / "SHA256.json", {p.name: sha(p) for p in sorted(folder.iterdir()) if p.is_file() and p.name != "SHA256.json"})
    return report


def run(allow_battery=False):
    prepared = verify()
    pre = preflight(allow_battery)
    run_id = uuid.uuid4().hex[:8]
    folder = ROOT / "results" / (datetime.now(ZoneInfo("Asia/Seoul")).strftime("%Y%m%d-%H%M%S-") + run_id)
    folder.mkdir(parents=True)
    manifest = {"started_at": now(), "state": "running", "protocol": P, "prepared": prepared,
                "preflight": pre, "schedule": schedule(), "warmups": [], "allow_battery": allow_battery}
    save(folder / "manifest.json", manifest)
    save(folder / "rows.json", [])
    rows, loader = [], None
    cases = {c["id"]: c for c in P["cases"]}
    workloads = {w["id"]: w for w in P["workloads"]}
    pending = WarmupRetryQueue(manifest["schedule"], P["warmup_retry_attempts"])
    manifest["warmup_failures"] = []
    manifest["attempts"] = []
    try:
        loader = output(["docker", "run", "-d", "--name", f"spine-compare-{run_id}-load", "--network", "host",
                         "--cpuset-cpus", P["load_cpus"], "--memory", P["load_memory"], "--memory-swap", P["load_memory"],
                         "--ulimit", "nofile=65535:65535", "-v", str(folder) + ":/results", P["load_image"]])
        for job, attempt in pending:
            power = power_status()
            if False:
                raise RuntimeError("측정 중 외부 전원이 분리됐습니다.")
            cid = start(cases[job["case"]], run_id)
            prefix = f"r{job['round']}-{job['case']}-a{attempt}"
            try:
                contract(cid, loader)
                print(json.dumps({"stage":"warmup","round":job["round"],"case":job["case"],"at":now()}),flush=True)
                warm = warmup(loader, folder, prefix)
                entry = {"round": job["round"], "case": job["case"], "attempt": attempt, "prefix": prefix, **warm}
                manifest["attempts"].append({"round": job["round"], "case": job["case"], "attempt": attempt, "stable": warm["stable"]})
                if not warm["stable"]:
                    manifest["warmup_failures"].append(entry)
                    pending.defer(job, attempt)
                    manifest["exhausted_jobs"] = pending.exhausted
                    save(folder / "manifest.json", manifest)
                    print(json.dumps({"stage": "warmup_deferred", "round": job["round"], "case": job["case"], "attempt": attempt, "last_three_cv": warm["last_three_cv"], "failure_kind": warm.get("failure_kind", "unstable"), "error": warm.get("error")}), flush=True)
                    continue
                manifest["warmups"].append(entry)
                save(folder / "manifest.json", manifest)
                for workload, concurrency in job["cells"]:
                    name = f"{prefix}-{workload}-c{concurrency}"
                    before_s, before_l, started = counter(cid), counter(loader), time.monotonic()
                    raw = load(loader, folder, name, workloads[workload], concurrency, P["duration_seconds"])
                    after_s, after_l = counter(cid), counter(loader)
                    wall = time.monotonic() - started
                    errors = sum(raw["errors"].values())
                    client_cpu = (after_l - before_l) / 1e6 / wall / P["load_cores"]
                    state = json.loads(output(["docker", "inspect", cid]))[0]["State"]
                    mem = memory(cid)
                    row = {"round": job["round"], "case": job["case"], "workload": workload, "concurrency": concurrency,
                           "rps": raw["requests"] / raw["duration_s"], "p99_ms": raw["latency_us"]["p99"] / 1000,
                           "errors": errors, "memory": mem, "measurement_wall_seconds": wall,
                           "server_cpu_usage_usec": after_s - before_s, "load_cpu_usage_usec": after_l - before_l,
                           "server_cpu_fraction": (after_s - before_s) / 1e6 / wall / P["server_cores"],
                           "load_cpu_fraction": client_cpu, "raw": name + ".json", "oom_killed": state["OOMKilled"],
                           "valid": raw_valid(raw, concurrency, P["duration_seconds"]) and client_cpu < P["max_load_cpu_fraction"]
                           and state["Running"] and not state["OOMKilled"] and not mem["events"].get("oom_kill", 0)}
                    rows.append(row)
                    save(folder / "rows.json", rows)
                    print(json.dumps({"completed": len(rows), "total": plan()["rows"], **row}), flush=True)
                contract(cid, loader)
                manifest.setdefault("post_contracts", []).append(prefix)
            finally:
                (folder / (prefix + "-server.log")).write_text(call(["docker", "logs", cid], check=False).stdout + call(["docker", "logs", cid], check=False).stderr)
                stop(cid)
                time.sleep(P["cooldown_seconds"])
        manifest["exhausted_jobs"] = pending.exhausted
        manifest["state"] = "incomplete" if pending.exhausted else "completed"
        if pending.exhausted:
            manifest["failure"] = "제한된 재시도 후에도 오류 없는 안정 예열을 통과하지 못한 항목이 있습니다."
    except BaseException as error:
        manifest["state"], manifest["failure"] = "incomplete", str(error)
        raise
    finally:
        if loader:
            stop(loader)
        manifest["ended_at"], manifest["ending_power"] = now(), power_status()
        manifest["sources_and_images_unchanged_at_end"] = (prepared["sources"] == sources() and prepared["images"] == images())
        save(folder / "manifest.json", manifest)
        print(json.dumps(audit(folder), ensure_ascii=False), flush=True)
        print(folder, flush=True)
    if manifest["state"] != "completed":
        raise RuntimeError(manifest["failure"])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["plan", "check", "seal", "verify", "run", "audit"])
    parser.add_argument("--allow-battery", action="store_true")
    parser.add_argument("--results", type=Path)
    args = parser.parse_args()
    if args.command == "plan":
        save(ROOT / "plan.json", plan())
        print(json.dumps({k: v for k, v in plan().items() if k != "schedule"}, ensure_ascii=False, indent=2))
    elif args.command == "check":
        check()
    elif args.command == "seal":
        seal()
    elif args.command == "verify":
        verify(); print("준비 파일과 이미지 해시 일치")
    elif args.command == "audit":
        if not args.results:
            parser.error("audit에는 --results 경로가 필요합니다.")
        print(json.dumps(audit(args.results), ensure_ascii=False, indent=2))
    else:
        run(args.allow_battery)


if __name__ == "__main__":
    main()
