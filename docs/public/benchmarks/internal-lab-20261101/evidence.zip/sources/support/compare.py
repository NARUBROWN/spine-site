"""동일한 로컬 Linux 자원에서 Echo와 Spine의 지연을 진단하고 원자료를 보존합니다."""
import csv
import hashlib
import importlib.util
import json
import platform
import random
import re
import shutil
import statistics
import subprocess
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPETITIONS = 3
DURATION = 15
CONCURRENCY = 256
IMAGES = {'echo': 'spine-latency-echo:20261031', 'spine': 'spine-comparison-spine:prepared'}
LOADER_IMAGE = 'spine-comparison-loadgen:prepared'
SOURCES = ROOT.parent / 'cloud-retry-errors-20261031/verified-final/suite'
spec = importlib.util.spec_from_file_location('baseline_cpu', ROOT.parent / 'baseline/benchmark.py')
baseline_cpu = importlib.util.module_from_spec(spec)
spec.loader.exec_module(baseline_cpu)


def command(args, check=True, timeout=60):
    p = subprocess.run([str(x) for x in args], capture_output=True, text=True, timeout=timeout)
    if check and p.returncode:
        raise RuntimeError(f'command failed: {args[:4]}: {p.stderr[-1500:]}')
    return p


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def inspect_image(name):
    data = json.loads(command(['docker', 'image', 'inspect', name]).stdout)[0]
    return {'id': data['Id'], 'architecture': data['Architecture'], 'environment': data['Config']['Env']}


def stats(cid):
    text = command(['docker', 'exec', cid, 'cat', '/sys/fs/cgroup/cpu.stat']).stdout
    cpu = {key: int(value) for key, value in (line.split() for line in text.splitlines())}
    memory = int(command(['docker', 'exec', cid, 'cat', '/sys/fs/cgroup/memory.current']).stdout)
    return {'cpu': cpu, 'memory_current': memory, 'monotonic': time.monotonic()}


def main():
    run_id = datetime.now().astimezone().strftime('%Y%m%d-%H%M%S')
    output = ROOT / 'results' / run_id
    output.mkdir(parents=True)
    images = {case: inspect_image(name) for case, name in IMAGES.items()}
    images['loader'] = inspect_image(LOADER_IMAGE)
    assert {x['architecture'] for x in images.values()} == {'arm64'}
    receipt_path = ROOT.parent / 'comparison/ready.json'
    receipt = json.loads(receipt_path.read_text())
    assert images['spine']['id'] == receipt['images'][IMAGES['spine']]
    assert images['loader']['id'] == receipt['images'][LOADER_IMAGE]
    spine_relative = 'apps/spine/internal/application/application.go'
    spine_hash = hashlib.sha256((SOURCES / spine_relative).read_bytes()).hexdigest()
    assert spine_hash == receipt['sources'][spine_relative]
    if command(['docker', 'ps', '-q']).stdout.strip():
        raise RuntimeError('다른 실행 중인 컨테이너가 있어 진단을 시작하지 않습니다.')
    power = command(['pmset', '-g', 'batt']).stdout
    if 'AC Power' not in power:
        raise RuntimeError('이번 진단은 외부 전원이 연결된 상태에서 시작합니다.')
    protocol = {'run_id': run_id, 'state': 'preflight', 'images': images,
        'scope': 'Local Linux/arm64 Docker diagnostic on Apple M4 Pro; not the prior cloud x86-64 environment.',
        'platform': platform.platform(), 'power': power, 'concurrency': CONCURRENCY,
        'repetitions': REPETITIONS, 'duration_seconds': DURATION,
        'server_cpuset': '0-2', 'server_cpu_limit': 3, 'server_memory': '3g',
        'load_cpuset': '3-11', 'load_memory': '1g',
        'network': 'Same loopback network namespace shared by server and load generator.',
        'fixed_rate_policy': 'Two common rates at 50% and 80% of the lower observed JSON closed-loop median, rounded down to 1000 req/s.',
        'diagnostics': 'Separate instrumented samples with GODEBUG=gctrace=1,schedtrace=1000; excluded from primary comparisons.',
        'host_cpu_policy': {'window_seconds': 20, 'maximum_mean_percent': 12,
                            'maximum_sample_percent': 15, 'maximum_stdev_percent': 1.5,
                            'scope': 'Diagnostic under recorded, stable background activity; not a quiescent publication benchmark.'},
        'spine_frozen_application_sha256': spine_hash,
        'prepared_image_receipt_sha256': hashlib.sha256(receipt_path.read_bytes()).hexdigest(),
        'source_hashes': {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                          for p in [ROOT / 'echo/main.go', ROOT / 'echo/go.mod', ROOT / 'echo/go.sum', ROOT / 'echo/Dockerfile', ROOT / 'compare.py']},
        'rows': [], 'contracts': []}
    for case, filename in [('spine', '/app/build-info.txt'), ('echo', '/app/echo-build-info.txt')]:
        info = command(['docker', 'run', '--rm', '--entrypoint', 'cat', images[case]['id'], filename]).stdout
        (output / f'{case}-build-info.txt').write_text(info)
        assert 'go1.27.3' in info and 'github.com/labstack/echo/v4\tv4.15.0' in info
    save(output / 'manifest.json', protocol)
    for source in [ROOT / 'compare.py', ROOT / 'echo/main.go', ROOT / 'echo/go.mod', ROOT / 'echo/go.sum', ROOT / 'echo/Dockerfile']:
        copied = output / 'sources' / source.relative_to(ROOT)
        copied.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, copied)
    print(json.dumps({'stage': 'preflight', 'run_id': run_id, 'output': str(output)}, ensure_ascii=False), flush=True)
    samples = []
    for _ in range(90):
        samples.append(baseline_cpu.host_cpu_busy())
        window = samples[-20:]
        if (len(window) == 20 and statistics.mean(window) < 12 and max(window) < 15
                and statistics.pstdev(window) < 1.5):
            break
    else:
        protocol.update(state='preflight_failed', preflight_cpu_samples=samples,
                        error='호스트 CPU가 사전 기록한 진단 안정 기준을 충족하지 못했습니다.')
        save(output / 'manifest.json', protocol)
        raise RuntimeError('호스트 CPU가 안정되지 않았습니다. 다른 작업을 종료하지 않고 중단합니다.')
    protocol['preflight_cpu_samples'] = samples
    loader = None
    server = None

    def stop_server():
        nonlocal server
        if server:
            command(['docker', 'rm', '-f', server], check=False)
            server = None

    def start(case, label, diagnostic=False):
        nonlocal server
        stop_server()
        args = ['docker', 'run', '-d', '--name', f'latency-{run_id}-{label}-{case}',
                '--network', f'container:{loader}', '--cpuset-cpus', '0-2', '--cpus', '3',
                '--memory', '3g', '--memory-swap', '3g', '--ulimit', 'nofile=65535:65535',
                '-e', 'GOMAXPROCS=3', '-e', 'GOMEMLIMIT=2700MiB']
        if diagnostic:
            args += ['-e', 'GODEBUG=gctrace=1,schedtrace=1000']
        server = command(args + [images[case]['id']]).stdout.strip()
        for _ in range(50):
            p = command(['docker', 'exec', loader, 'python', '-c',
                         'import urllib.request; assert urllib.request.urlopen("http://127.0.0.1:3000/").status==200'], check=False)
            if p.returncode == 0:
                break
            time.sleep(.1)
        else:
            raise RuntimeError('서버 시작 시간 초과')
        contract_script = '''import json,urllib.request,urllib.error
base="http://127.0.0.1:3000"
with urllib.request.urlopen(base+"/") as r: assert r.status==200 and r.read()==b""
samples=[({"id":42,"name":"benchmark","active":True},200),({"id":0,"name":"benchmark","active":True},400),({"id":42,"name":"","active":True},400),({"id":42,"name":"benchmark"},400)]
for body,expected in samples:
 req=urllib.request.Request(base+"/json",data=json.dumps(body).encode(),headers={"Content-Type":"application/json"})
 try: response=urllib.request.urlopen(req)
 except urllib.error.HTTPError as error: response=error
 with response as r:
  assert r.status==expected,(r.status,expected)
  if expected==200: assert json.loads(r.read())==body
print("5 common HTTP fixtures passed")'''
        checked = command(['docker', 'exec', loader, 'python', '-c', contract_script]).stdout
        protocol['contracts'].append({'case': case, 'label': label, 'result': checked.strip()})
        load(case, label + '-warmup', 'json', mode='closed', duration=10, retain=False)

    def load(case, label, workload, mode='closed', rate=None, duration=DURATION, retain=True):
        prefix = f'{label}-{case}-{workload}'
        raw_path = output / f'{prefix}.json'
        args = ['docker', 'exec', loader, 'zrk', '--plain', '-t', '9', '--connections', str(CONCURRENCY),
                '--duration', f'{duration}s', '--timeout', '8s', '--interval', '1s',
                '--format', 'json', '--output', f'/results/{prefix}.json',
                '--timeseries', f'/results/{prefix}.ndjson', '-H', 'Accept-Encoding:identity']
        args += ['--closed'] if mode == 'closed' else ['--rate', str(rate)]
        if workload == 'json':
            args += ['--method', 'POST', '--body', '@/opt/payload.json', '-H', 'Content-Type:application/json']
        args += ['http://127.0.0.1:3000/' + ('json' if workload == 'json' else '')]
        before = stats(server)
        result = command(args, timeout=duration + 60)
        after = stats(server)
        (output / f'{prefix}.log').write_text(result.stdout + result.stderr)
        raw = json.loads(raw_path.read_text())
        errors = sum(raw['errors'].values())
        assert raw['zrk_version'] == '2.4.2' and raw['requests'] > 0 and not errors
        assert raw['status_codes']['2xx'] == raw['requests']
        assert raw['config']['closed'] == (mode == 'closed')
        assert raw['config']['launched'] == CONCURRENCY
        state = json.loads(command(['docker', 'inspect', server]).stdout)[0]['State']
        assert state['Running'] and not state['OOMKilled']
        delta = {k: after['cpu'].get(k, 0) - before['cpu'].get(k, 0) for k in after['cpu']}
        row = {'phase': mode, 'case': case, 'label': label, 'workload': workload, 'rate': rate,
               'rps': raw['requests'] / raw['duration_s'],
               **{key + '_ms': raw['latency_us'][key] / 1000 for key in ['mean', 'p50', 'p90', 'p99', 'max']},
               'errors': errors, 'cpu_delta': delta, 'memory_current': after['memory_current'],
               'server_cpu_fraction': delta['usage_usec'] / 1e6 / (after['monotonic'] - before['monotonic']) / 3,
               'rate_ratio': raw.get('rate_ratio'), 'max_schedule_lag_us': raw.get('max_schedule_lag_us'),
               'raw': raw_path.name}
        save(output / f'{prefix}-resource.json', {'before': before, 'after': after, 'row': row})
        if retain:
            protocol['rows'].append(row)
            save(output / 'manifest.json', protocol)
            print(json.dumps({'stage': 'sample', **row}, ensure_ascii=False), flush=True)
        return row

    try:
        loader = command(['docker', 'run', '-d', '--name', f'latency-{run_id}-load',
                          '--cpuset-cpus', '3-11', '--memory', '1g', '--memory-swap', '1g',
                          '-v', f'{output}:/results', images['loader']['id']]).stdout.strip()
        protocol['state'] = 'running'
        rng = random.Random(2601031)
        for round_id in range(1, REPETITIONS + 1):
            cases = list(IMAGES)
            rng.shuffle(cases)
            for case in cases:
                label = f'closed-r{round_id}'
                start(case, label)
                for workload in ['empty', 'json']:
                    load(case, label, workload)
                (output / f'{label}-{case}-server.log').write_text(command(['docker', 'logs', server]).stdout + command(['docker', 'logs', server]).stderr)
                stop_server()
        medians = {case: statistics.median(row['rps'] for row in protocol['rows']
                   if row['phase'] == 'closed' and row['case'] == case and row['workload'] == 'json') for case in IMAGES}
        ceiling = min(medians.values())
        rates = sorted({max(1000, int(ceiling * fraction / 1000) * 1000) for fraction in [.5, .8]})
        protocol['fixed_rates'] = rates
        print(json.dumps({'stage': 'fixed-rate-calibration', 'closed_json_medians': medians, 'rates': rates}), flush=True)
        for round_id in range(1, REPETITIONS + 1):
            cases = list(IMAGES)
            rng.shuffle(cases)
            for case in cases:
                label = f'fixed-r{round_id}'
                start(case, label)
                for rate in rates:
                    load(case, f'{label}-rate{rate}', 'json', mode='fixed', rate=rate)
                stop_server()
        for case in IMAGES:
            start(case, 'diagnostic', diagnostic=True)
            row = load(case, 'diagnostic', 'json')
            row['phase'] = 'instrumented'
            logged = command(['docker', 'logs', server])
            text = logged.stdout + logged.stderr
            (output / f'diagnostic-{case}-server.log').write_text(text)
            gc = re.findall(r'gc \d+ @([\d.]+)s.*?: ([\d.]+)\+([\d.]+)\+([\d.]+) ms clock', text)
            protocol.setdefault('runtime_diagnostics', {})[case] = {
                'gc_events_logged': len(gc),
                'maximum_logged_gc_stop_clock_ms': max((float(x[1]) + float(x[3]) for x in gc), default=None),
                'maximum_logged_gc_concurrent_clock_ms': max((float(x[2]) for x in gc), default=None),
                'scheduler_lines': [line for line in text.splitlines() if line.startswith('SCHED ')],
                'note': 'GC records include startup, contract fixtures and warmup; instrumented sample excluded from primary medians.'}
            stop_server()
        protocol['state'] = 'completed'
    except BaseException as error:
        protocol['state'] = 'failed'
        protocol['error'] = str(error)
        raise
    finally:
        stop_server()
        if loader:
            command(['docker', 'rm', '-f', loader], check=False)
        protocol['cleanup_completed'] = True
        protocol['ended_at'] = datetime.now().astimezone().isoformat()
        save(output / 'manifest.json', protocol)
        print(json.dumps({'stage': protocol['state'], 'rows': len(protocol['rows']), 'output': str(output)}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    main()
