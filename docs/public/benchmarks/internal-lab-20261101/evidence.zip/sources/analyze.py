"""보존된 원시 HDR 히스토그램과 자원 표본으로 비교 보고서를 만듭니다."""
import csv
import hashlib
import html
import json
import statistics
import sys
from collections import defaultdict
from datetime import datetime
from pathlib import Path

from hdrh.histogram import HdrHistogram

ROOT = Path(__file__).resolve().parent
LABELS = {'spine': 'Spine · GOGC=400', 'nest': 'NestJS / Express',
          'spring-mvc': 'Spring MVC', 'fastapi': 'FastAPI / Uvicorn'}
ORDER = list(LABELS)


def main():
    folder = Path(sys.argv[1]) if len(sys.argv) > 1 else sorted((ROOT / 'results').iterdir())[-1]
    m = json.loads((folder / 'manifest.json').read_text())
    assert m['state'] == 'completed' and m['cleanup_completed']
    assert len(m['rows']) == 30
    rows, groups = [], defaultdict(list)
    checks = {'expected_samples': 30, 'actual_samples': len(m['rows']),
              'contracts': len(m['contracts']), 'contract_fixtures': 0,
              'source_hashes': 0, 'histograms': 0, 'server_states': len(m['server_states']),
              'warmup_failures': len(m['warmup_failures']), 'primary_errors': 0,
              'oom': 0, 'oom_check': 'Docker State.OOMKilled checked after primary samples and before each server removal',
              'fixed_rate_misses': [], 'cleanup_completed': m['cleanup_completed']}
    for relative, expected in m['source_hashes'].items():
        assert hashlib.sha256((folder / 'sources' / relative).read_bytes()).hexdigest() == expected
        checks['source_hashes'] += 1
    for prefix, contracts in m['contracts'].items():
        assert len(contracts) == 14 and all(v['passed'] for v in contracts), prefix
        checks['contract_fixtures'] += len(contracts)
    for prefix, state in m['server_states'].items():
        assert state['State']['Running'] and not state['State']['OOMKilled'], prefix
        assert state['HostConfig']['NanoCpus'] == 3_000_000_000
        assert state['HostConfig']['Memory'] == state['HostConfig']['MemorySwap'] == 3 * 1024**3
        assert state['HostConfig']['CpusetCpus'] == '0-2'
        if '-spine-' in prefix:
            for env in ['GOGC=400', 'GOMAXPROCS=3', 'GOMEMLIMIT=2700MiB']:
                assert env in state['Env']
        if '-nest-' in prefix:
            assert 'ADAPTER=express' in state['Env']
    for original in m['rows']:
        row = dict(original)
        raw = json.loads((folder / row['raw']).read_text())
        histogram = HdrHistogram.decode(raw['latency_histogram'])
        assert histogram.total_count == raw['requests'] == row['requests']
        assert row['valid'] and all(row['checks'].values())
        assert sum(raw['errors'].values()) == row['errors'] == 0
        assert raw['status_codes']['2xx'] == raw['requests']
        for percentile, key in [(50, 'p50'), (90, 'p90'), (99, 'p99')]:
            decoded = histogram.get_value_at_percentile(percentile)
            assert histogram.get_lowest_equivalent_value(decoded) == histogram.get_lowest_equivalent_value(raw['latency_us'][key])
        row['p95_ms'] = histogram.get_value_at_percentile(95) / 1000
        row['p99_histogram_upper_ms'] = histogram.get_value_at_percentile(99) / 1000
        row['max_schedule_lag_ms'] = raw['max_schedule_lag_us'] / 1000
        row['cpu_us_per_request'] = row['cpu_delta']['usage_usec'] / row['requests']
        row['mode_key'] = 'closed' if row['mode'] == 'closed' else f'fixed-{row["target_rps"]}'
        rows.append(row)
        groups[(row['case'], row['mode_key'])].append(row)
        checks['histograms'] += 1
        if row['target_below_98_percent']:
            checks['fixed_rate_misses'].append(row['raw'])
    summary = []
    metrics = ['rps', 'mean_ms', 'p50_ms', 'p95_ms', 'p99_ms', 'memory_current_median_mib',
               'memory_current_sampled_max_mib', 'cgroup_lifetime_memory_peak_mib',
               'cpu_us_per_request', 'server_cpu_fraction', 'loader_cores_used',
               'max_schedule_lag_ms', 'rate_ratio']
    for mode in ['closed', 'fixed-20000', 'fixed-118000']:
        for case in ORDER:
            group = groups.get((case, mode), [])
            if not group:
                continue
            assert len(group) == 3 and {r['round'] for r in group} == {1, 2, 3}
            for r in group:
                prefix = r['raw'].split('-closed')[0].split('-fixed')[0]
                assert m['warmups'][prefix]['stable']
            item = {'case': case, 'mode': mode, 'n': 3,
                    'rate_misses': sum(r['target_below_98_percent'] for r in group)}
            for metric in metrics:
                vals = [r[metric] for r in group]
                item[metric] = statistics.median(vals)
                item[metric + '_min'] = min(vals)
                item[metric + '_max'] = max(vals)
            summary.append(item)
    lookup = {(r['case'], r['mode']): r for r in summary}
    comparisons = []
    for mode in ['closed', 'fixed-20000', 'fixed-118000']:
        spine = lookup[('spine', mode)]
        for case in ['nest', 'spring-mvc', 'fastapi']:
            other = lookup.get((case, mode))
            if not other:
                continue
            comparisons.append({'mode': mode, 'other': case,
                'spine_rps_divided_by_other': spine['rps'] / other['rps'],
                'spine_p95_divided_by_other': spine['p95_ms'] / other['p95_ms'],
                'spine_p99_divided_by_other': spine['p99_ms'] / other['p99_ms'],
                'spine_memory_divided_by_other': spine['memory_current_median_mib'] / other['memory_current_median_mib'],
                'spine_memory_reduction_percent': (1-spine['memory_current_median_mib']/other['memory_current_median_mib'])*100})
    analysis = {'run_id': m['run_id'], 'summary': summary, 'comparisons': comparisons,
                'rows': rows, 'verification': checks,
                'percentile_method': 'Median of three independent-start window percentiles; p95 is decoded from raw HDR histogram (upper-equivalent bound). p99 is zrk reported bucket median, bucket-checked against HDR. No averaging or pooling of percentiles.',
                'limitations': ['한 로컬 Docker 호스트에서 구현마다 세 번 새로 시작한 기술 통계입니다. 통계적 유의성이나 공식 WFB 순위를 입증하는 실험은 아닙니다.',
                    'Spine에는 GOGC=400을 명시적으로 적용했습니다. 프레임워크 소스나 기본 설정을 변경한 결과는 아닙니다.',
                    '고정 요청률 지연은 예정된 송신 시각부터 계산해 송신 대기도 포함합니다. 포화 부하 지연은 응답 뒤 다음 요청을 보내는 방식이므로 같은 부하 방식끼리 비교해야 합니다.',
                    'cgroup memory.current는 프로세스와 런타임, 페이지 캐시 등의 사용량을 포함합니다. 프로세스 RSS나 최소 필요 RAM을 뜻하지 않습니다.',
                    'JSON 파싱·필드 검증·응답 직렬화만 측정했습니다. DB, CORS·인증·TLS, 외부 I/O와 요청별 주입 서비스 호출은 포함하지 않았습니다.',
                    '안정성 기준을 통과한 예열 뒤 15초씩 측정했습니다. 구현과 부하 순서를 회차마다 바꿨지만 모든 순열을 시험하지는 않았습니다.',
                    '모든 구현에 같은 방식의 1초 간격 cgroup 메모리 관측을 적용했습니다. Docker exec를 사용하는 소량의 관측 비용도 포함됩니다.']}
    (folder / 'analysis.json').write_text(json.dumps(analysis, ensure_ascii=False, indent=2) + '\n')
    (folder / 'verification.json').write_text(json.dumps(checks, ensure_ascii=False, indent=2) + '\n')
    fields = ['case', 'mode', 'n', 'rps', 'mean_ms', 'p50_ms', 'p95_ms', 'p99_ms', 'p99_ms_min', 'p99_ms_max',
        'memory_current_median_mib', 'cgroup_lifetime_memory_peak_mib', 'cpu_us_per_request', 'loader_cores_used',
        'max_schedule_lag_ms', 'rate_misses']
    with (folder / 'summary.csv').open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(summary)
    with (folder / 'samples.csv').open('w', newline='') as stream:
        samplefields = ['case', 'round', 'attempt', 'mode_key', 'requests', *metrics, 'target_below_98_percent', 'raw']
        writer = csv.DictWriter(stream, fieldnames=samplefields, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)
    sections = []
    for mode, title, intro in [
        ('closed', '동시 연결 256개 · 포화 처리량', '서버가 처리한 응답 뒤 다음 요청을 보냅니다. 각 서버의 실제 처리량이 달라 이 표의 지연을 동일 요청률 결과로 해석하지 않습니다.'),
        ('fixed-20000', '공통 부하 · 초당 20,000 요청', '네 구현에 같은 요청률을 제공합니다. p95/p99와 메모리는 이 조건끼리 비교합니다.'),
        ('fixed-118000', '고부하 · 초당 118,000 요청', 'Spine과 Spring MVC의 추가 비교입니다. 목표 달성률 98% 미만 표본도 보존했습니다.')]:
        body = ''
        for item in summary:
            if item['mode'] != mode:
                continue
            body += f'<tr><td>{LABELS[item["case"]]}</td><td>{item["rps"]:,.0f}</td><td>{item["mean_ms"]:.3f}</td><td>{item["p95_ms"]:.3f}</td><td>{item["p99_ms"]:.3f}<small>{item["p99_ms_min"]:.3f}–{item["p99_ms_max"]:.3f}</small></td><td>{item["memory_current_median_mib"]:.1f}</td><td>{item["rate_misses"]}/3</td></tr>'
        extra = ''
        if mode == 'fixed-118000':
            sp, spring = lookup[('spine', mode)], lookup[('spring-mvc', mode)]
            extra = f'<p>서버 CPU 한도 사용률 중앙값: Spine {sp["server_cpu_fraction"]*100:.1f}%, Spring MVC {spring["server_cpu_fraction"]*100:.1f}%. 고정 요청률 지연에는 송신 대기가 포함되므로, 한계 처리량에 가까운 조건에서의 결과로 해석해야 합니다.</p>'
        sections.append(f'<section><h2>{title}</h2><p>{intro}</p><div class="scroll"><table><thead><tr><th>구현</th><th>처리량 req/s</th><th>평균 ms</th><th>p95 ms</th><th>p99 ms / 범위</th><th>메모리 MiB</th><th>목표 98% 미달</th></tr></thead><tbody>{body}</tbody></table></div>{extra}</section>')
    rowbody = ''.join(f'<tr><td>{r["round"]}</td><td>{LABELS[r["case"]]}</td><td>{r["mode_key"]}</td><td>{r["rps"]:,.0f}</td><td>{r["p95_ms"]:.3f}</td><td>{r["p99_ms"]:.3f}</td><td>{r["memory_current_median_mib"]:.1f}</td><td>{r["max_schedule_lag_ms"]:.3f}</td><td>{r["loader_cores_used"]:.2f}</td></tr>' for r in rows)
    source_versions = ''.join(f'<h3>{LABELS[k]}</h3><pre>{html.escape(v)}</pre>' for k,v in m['versions'].items())
    limitations = ''.join(f'<li>{html.escape(v)}</li>' for v in analysis['limitations'])
    report = f'''<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Spine GOGC=400 내부 비교</title>
<style>body{{background:#f7f8fa;color:#172333;font:16px/1.6 system-ui,sans-serif;margin:0}}main{{max-width:1160px;margin:auto;padding:36px 24px}}h1{{font-size:34px;line-height:1.25}}h2{{font-size:23px}}h3{{font-size:18px}}section{{background:white;border:1px solid #dce3e9;border-radius:12px;padding:22px;margin:22px 0}}.meta{{color:#506274}}.scroll{{overflow:auto}}table{{width:100%;border-collapse:collapse;font-variant-numeric:tabular-nums;white-space:nowrap}}th,td{{padding:12px;text-align:right;border-bottom:1px solid #e4e8ed}}th:first-child,td:first-child{{text-align:left}}thead{{color:#496176;background:#f2f6fa}}small{{display:block;color:#68798a;font-size:12px}}pre{{white-space:pre-wrap;font-size:12px;background:#f2f6fa;padding:14px}}a{{color:#1164ab}}li{{margin:8px 0}}</style>
<main><p class="meta">내부 랩 · Linux/arm64 Docker · {html.escape(m['run_id'])}</p><h1>Spine GOGC=400 비교 결과</h1>
<p>Spine · NestJS/Express · Spring MVC · FastAPI/Uvicorn. 각 구현을 독립적으로 세 번 시작하고 예열 안정성을 확인했습니다. 표는 세 측정 창의 중앙값이며 p99 아래에 최솟값–최댓값을 표시합니다.</p>
<p>서버 3 vCPU / 3GiB, 부하 생성기 별도 CPU 9개, 동시 연결 256개. 같은 JSON 파싱·필드 검증·응답 작업, 창당 15초. Spine은 GOGC=400 / GOMAXPROCS=3 / GOMEMLIMIT=2700MiB입니다.</p>
<p>검증: 본 측정 {checks['actual_samples']}/30개, 요청 오류 {checks['primary_errors']}개, Docker OOMKilled 표시 {checks['oom']}개, HTTP 계약 {checks['contract_fixtures']}개 통과. 예열 실패 {checks['warmup_failures']}회. 실험 컨테이너 정리 완료.</p>
{''.join(sections)}<section><h2>해석 범위</h2><ul>{limitations}</ul><p>메모리는 각 측정 창에서 1초 간격으로 읽은 cgroup memory.current의 중앙값을 다시 세 실행에 걸쳐 중앙값으로 요약했습니다. memory.peak는 시작·예열을 포함하는 컨테이너 생애 최고값으로 별도 원시 파일에 보존했습니다.</p><p>p95는 원시 HDR 히스토그램에서 계산했고, 모든 히스토그램의 요청 수와 p50/p90/p99 버킷을 검증했습니다.</p></section>
<details><summary>30개 표본 전체</summary><section><div class="scroll"><table><thead><tr><th>회차</th><th>구현</th><th>부하</th><th>req/s</th><th>p95 ms</th><th>p99 ms</th><th>메모리 MiB</th><th>최대 송신 지연 ms</th><th>부하기 사용 코어</th></tr></thead><tbody>{rowbody}</tbody></table></div></section></details>
<details><summary>실제 실행 버전</summary><section>{source_versions}</section></details>
<p><a href="analysis.json">상세 JSON</a> · <a href="summary.csv">요약 CSV</a> · <a href="samples.csv">전체 표본 CSV</a> · <a href="manifest.json">실행 기록</a> · <a href="verification.json">검증 기록</a></p></main></html>'''
    (folder / 'report.html').write_text(report)
    shutil_target = folder / 'sources/analyze.py'
    shutil_target.write_bytes(Path(__file__).read_bytes())
    hashes = {str(p.relative_to(folder)): hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(folder.rglob('*')) if p.is_file() and p.name != 'SHA256.json'}
    (folder / 'SHA256.json').write_text(json.dumps(hashes, indent=2) + '\n')
    for relative, expected in hashes.items():
        assert hashlib.sha256((folder / relative).read_bytes()).hexdigest() == expected
    print(json.dumps({'summary': summary, 'comparisons': comparisons, 'verification': checks,
                      'hashed_files': len(hashes), 'report': str(folder / 'report.html')}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
