"""GOGC=400 Spine과 세 비교군을 같은 조건에서 다시 측정합니다."""
import concurrent.futures
import hashlib
import importlib.util
import json
import platform
import shutil
import statistics
import threading
import time
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PREP = ROOT.parent
FROZEN = PREP / 'cloud-retry-errors-20261031/verified-final/suite'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


h = module('helpers', PREP / 'latency-echo-spine-20261031/compare.py')
warm = module('warmup', FROZEN / 'bench.py')
command, save, stats = h.command, h.save, h.stats
CASES = ['spine', 'nest', 'spring-mvc', 'fastapi']
ORDERS = [CASES, ['nest', 'fastapi', 'spine', 'spring-mvc'],
          ['fastapi', 'spring-mvc', 'nest', 'spine']]
DURATION = 15


def now():
    return datetime.now().astimezone().isoformat()


def main():
    run_id = datetime.now().astimezone().strftime('%Y%m%d-%H%M%S')
    output = ROOT / 'results' / run_id
    output.mkdir(parents=True)
    assert not command(['docker', 'ps', '-q']).stdout.strip(), '다른 컨테이너가 실행 중입니다.'
    power = command(['pmset', '-g', 'batt']).stdout
    assert 'AC Power' in power, 'AC 전원을 연결해야 합니다.'
    receipt = json.loads((PREP / 'comparison/ready.json').read_text())
    images = {c: h.inspect_image(f'spine-comparison-{c}:prepared') for c in CASES}
    images['loader'] = h.inspect_image(h.LOADER_IMAGE)
    for case, value in images.items():
        tag = h.LOADER_IMAGE if case == 'loader' else f'spine-comparison-{case}:prepared'
        assert value['id'] == receipt['images'][tag]
        assert value['architecture'] == 'arm64'
    manifest = {'run_id': run_id, 'started_at': now(), 'state': 'preflight',
        'platform': platform.platform(), 'power': power, 'images': images,
        'orders': ORDERS, 'repetitions': 3, 'independent_server_starts_per_case': 3,
        'server_cpus': '0-2', 'server_cpu_limit': 3, 'server_memory': '3g',
        'load_cpus': '3-11', 'load_memory': '1g', 'concurrency': 256,
        'duration_seconds': DURATION, 'common_target_rps': 20000, 'high_target_rps': 118000,
        'expected_primary_samples': 30, 'workload': 'POST /json; 43-byte payload; validation and JSON echo response',
        'scope': 'Local Linux/arm64 Docker internal comparison; no DB, TLS, auth, CORS or injected service call in the per-request path.',
        'runtime_settings': {'spine': {'GOGC': 400, 'GOMAXPROCS': 3, 'GOMEMLIMIT': '2700MiB'},
            'nest': 'ADAPTER=express; original image entrypoint; three cluster workers',
            'spring-mvc': 'Original Java entrypoint; ActiveProcessorCount=3; MaxRAMPercentage=60; virtual threads',
            'fastapi': 'Original Uvicorn entrypoint; three workers; uvloop and httptools'},
        'warmup_policy': {'window_seconds': 15, 'cv_limit': .05, 'minimum_seconds': {'spring-mvc': 135, 'other': 45},
            'maximum_seconds': {'spring-mvc': 360, 'other': 180}, 'workload': 'JSON only',
            'maximum_attempts': 3, 'retry': 'Fresh server after a failed or unstable warmup; append retry to the end of the queue'},
        'memory_policy': 'memory.current sampled once per second during load. memory.peak is cgroup lifetime peak including startup and warmup. Neither is process RSS.',
        'fixed_rate_policy': 'Latency includes coordinated omission correction from scheduled send. Retain and flag achievement below 98%. No selective primary reruns.',
        'host_cpu_policy': {'window_seconds': 20, 'maximum_mean_percent': 12, 'maximum_sample_percent': 15,
            'maximum_stdev_percent': 1.5, 'maximum_wait_seconds': 120},
        'rows': [], 'contracts': {}, 'warmups': {}, 'warmup_failures': [], 'server_states': {},
        'versions': {}, 'preflight_cpu_samples': [], 'source_hashes': {},
        'source_origin': 'Prepared local ARM64 images and sources from comparison/ready.json. Request handlers equal the preserved cloud suite.',
        'platform_input_differences': {}}
    copied = [(ROOT / 'run.py', 'run.py'),
              (PREP / 'latency-echo-spine-20261031/compare.py', 'support/compare.py'),
              (PREP / 'baseline/benchmark.py', 'support/baseline.py'),
              (FROZEN / 'bench.py', 'support/cloud-bench.py'),
              (FROZEN / 'protocol.json', 'support/cloud-protocol.json')]
    for relative, expected in receipt['sources'].items():
        if any(relative.startswith(f'apps/{c}/') for c in CASES) or relative in ['payload.json', 'scripts/http_contract.py', 'Loadgen.Dockerfile']:
            source = PREP / 'comparison' / relative
            assert hashlib.sha256(source.read_bytes()).hexdigest() == expected, relative
            frozen_hash = hashlib.sha256((FROZEN / relative).read_bytes()).hexdigest()
            if frozen_hash != expected:
                assert relative in ['apps/fastapi/requirements.lock', 'apps/fastapi/resolved.json', 'apps/spine/Dockerfile'], relative
                manifest['platform_input_differences'][relative] = {'prepared_arm64_sha256': expected,
                    'preserved_cloud_x86_sha256': frozen_hash,
                    'reason': 'Architecture-specific wheel hashes/resolution or Go ARM64 build target. Prepared image is unchanged.'}
            copied.append((source, relative))
    for source, relative in copied:
        target = output / 'sources' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        manifest['source_hashes'][relative] = hashlib.sha256(source.read_bytes()).hexdigest()
    save(output / 'manifest.json', manifest)
    print(json.dumps({'stage': 'preflight', 'output': str(output)}), flush=True)
    for index in range(120):
        manifest['preflight_cpu_samples'].append(h.baseline_cpu.host_cpu_busy())
        window = manifest['preflight_cpu_samples'][-20:]
        if len(window) == 20 and statistics.mean(window) < 12 and max(window) < 15 and statistics.pstdev(window) < 1.5:
            break
        if index % 10 == 9:
            manifest['updated_at'] = now()
            save(output / 'manifest.json', manifest)
            print(json.dumps({'stage': 'preflight-wait', 'samples': index + 1, 'cpu_mean': statistics.mean(window)}), flush=True)
    else:
        manifest.update(state='preflight_failed', updated_at=now())
        save(output / 'manifest.json', manifest)
        raise RuntimeError('측정 전 호스트 CPU가 안정 기준을 충족하지 못했습니다.')
    loader = server = None

    def phase(job, name, **extra):
        manifest.update(state='running', updated_at=now(), active={**job, 'phase': name, **extra})
        save(output / 'manifest.json', manifest)
        print(json.dumps({'stage': name, **job, **extra}), flush=True)

    def stop_server(prefix):
        nonlocal server
        if server:
            inspected = json.loads(command(['docker', 'inspect', server]).stdout)[0]
            manifest['server_states'][prefix] = {'State': inspected['State'], 'HostConfig': {
                k: inspected['HostConfig'][k] for k in ['NanoCpus', 'CpusetCpus', 'Memory', 'MemorySwap']},
                'Env': inspected['Config']['Env']}
            logged = command(['docker', 'logs', server], check=False)
            (output / f'{prefix}-server.log').write_text(logged.stdout + logged.stderr)
            command(['docker', 'rm', '-f', server])
            server = None

    def sample_memory(cid, stop_event):
        readings = []
        while not stop_event.is_set():
            r = command(['docker', 'exec', cid, 'cat', '/sys/fs/cgroup/memory.current', '/sys/fs/cgroup/memory.peak'], check=False)
            values = r.stdout.splitlines()
            if r.returncode == 0 and len(values) == 2:
                readings.append({'monotonic': time.monotonic(), 'memory_current': int(values[0]),
                    'memory_peak_including_startup': int(values[1])})
            if stop_event.wait(1):
                break
        return readings

    def measure(job, prefix, mode, target):
        name = f'{prefix}-{mode}' + (f'-{target}' if target else '')
        phase(job, 'measurement', mode=mode, target_rps=target, raw=name + '.json')
        args = ['docker', 'exec', loader, 'zrk', '--plain', '-t', '9', '--connections', '256',
            '--duration', f'{DURATION}s', '--timeout', '8s', '--interval', '1s', '--format', 'json',
            '--output', f'/results/{name}.json', '--timeseries', f'/results/{name}.ndjson',
            '-H', 'Accept-Encoding:identity', '--method', 'POST', '--body', '@/opt/payload.json',
            '-H', 'Content-Type:application/json']
        args += ['--closed'] if mode == 'closed' else ['--rate', str(target)]
        args += ['http://127.0.0.1:3000/json']
        loader_before = stats(loader)
        before = stats(server)
        stop = threading.Event()
        pool = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        future = pool.submit(sample_memory, server, stop)
        try:
            result = command(args, check=False, timeout=DURATION + 60)
        finally:
            stop.set()
            readings = future.result()
            pool.shutdown()
        after = stats(server)
        loader_after = stats(loader)
        (output / f'{name}.log').write_text(json.dumps(args) + '\n' + result.stdout + result.stderr)
        state = json.loads(command(['docker', 'inspect', server]).stdout)[0]['State']
        resources = {'before': before, 'after': after, 'loader_before': loader_before,
            'loader_after': loader_after, 'memory_samples': readings, 'server_state': state,
            'load_tool_exit_code': result.returncode}
        save(output / f'{name}-resource.json', resources)
        raw = json.loads((output / f'{name}.json').read_text())
        config = raw['config']
        checks = {'load_tool_exit': result.returncode == 0, 'zrk_version': raw['zrk_version'] == '2.4.2',
            'closed': config['closed'] == (mode == 'closed'), 'connections': config['connections'] == config['launched'] == 256,
            'duration': config['duration_s'] == DURATION, 'keepalive': not config['disable_keepalive'],
            'requests': raw['requests'] > 0, 'errors': sum(raw['errors'].values()) == 0,
            'http_status': raw['status_codes']['2xx'] == raw['requests'],
            'server_alive': state['Running'] and not state['OOMKilled'], 'memory_samples': len(readings) >= 10}
        delta = {k: after['cpu'][k] - before['cpu'].get(k, 0) for k in after['cpu']}
        loader_delta = {k: loader_after['cpu'][k] - loader_before['cpu'].get(k, 0) for k in loader_after['cpu']}
        row = {**job, 'mode': mode, 'target_rps': target, 'requests': raw['requests'],
            'rps': raw['requests'] / raw['duration_s'],
            **{k + '_ms': raw['latency_us'][k] / 1000 for k in ['mean', 'p50', 'p75', 'p90', 'p99', 'max']},
            'errors': sum(raw['errors'].values()), 'rate_ratio': raw['rate_ratio'],
            'target_below_98_percent': mode != 'closed' and raw['rate_ratio'] < .98,
            'cpu_delta': delta, 'loader_cpu_delta': loader_delta,
            'server_cpu_fraction': delta['usage_usec'] / 1e6 / (after['monotonic'] - before['monotonic']) / 3,
            'loader_cores_used': loader_delta['usage_usec'] / 1e6 / (loader_after['monotonic'] - loader_before['monotonic']),
            'memory_current_median_mib': statistics.median(x['memory_current'] for x in readings) / 1024**2,
            'memory_current_sampled_max_mib': max(x['memory_current'] for x in readings) / 1024**2,
            'cgroup_lifetime_memory_peak_mib': max(x['memory_peak_including_startup'] for x in readings) / 1024**2,
            'raw': name + '.json', 'checks': checks, 'valid': all(checks.values())}
        manifest['rows'].append(row)
        save(output / 'manifest.json', manifest)
        print(json.dumps({'stage': 'sample', **row}), flush=True)
        assert row['valid'], f'본 측정 검증 실패: {name}: {checks}'

    prefix = 'not-started'
    try:
        loader = command(['docker', 'run', '-d', '--name', f'fourway-{run_id}-load', '--cpuset-cpus', '3-11',
            '--memory', '1g', '--memory-swap', '1g', '-v', f'{output}:/results', images['loader']['id']]).stdout.strip()
        queue = [{'round': r, 'case': c, 'attempt': 1} for r, order in enumerate(ORDERS, 1) for c in order]
        completed = set()
        while queue:
            job = queue.pop(0)
            case = job['case']
            prefix = f'r{job["round"]}-{case}-a{job["attempt"]}'
            phase(job, 'starting')
            args = ['docker', 'run', '-d', '--name', f'fourway-{run_id}-{prefix}', '--network', f'container:{loader}',
                '--cpuset-cpus', '0-2', '--cpus', '3', '--memory', '3g', '--memory-swap', '3g',
                '--ulimit', 'nofile=65535:65535']
            if case == 'spine':
                args += ['-e', 'GOGC=400', '-e', 'GOMAXPROCS=3', '-e', 'GOMEMLIMIT=2700MiB']
            elif case == 'nest':
                args += ['-e', 'ADAPTER=express']
            server = command(args + [images[case]['id']]).stdout.strip()
            phase(job, 'contract')
            probe = command(['docker', 'exec', loader, 'python', '/opt/http_contract.py'], timeout=90)
            contract = json.loads(probe.stdout)
            assert len(contract) == 14 and all(c['passed'] for c in contract)
            manifest['contracts'][prefix] = contract
            if case not in manifest['versions']:
                version_args = {'spine': ['cat', '/app/build-info.txt'],
                    'nest': ['node', '-e', 'console.log(JSON.stringify({node:process.version,nest:require("@nestjs/core/package.json").version,express:require("express/package.json").version}))'],
                    'spring-mvc': ['java', '-version'],
                    'fastapi': ['python', '-c', 'import sys,json,importlib.metadata as m;print(json.dumps({"runtime":sys.version,"packages":{n:m.version(n) for n in ["fastapi","uvicorn","uvloop","httptools","pydantic","starlette"]}}))']}[case]
                vr = command(['docker', 'exec', server] + version_args)
                manifest['versions'][case] = vr.stdout + vr.stderr
            phase(job, 'warmup')
            warm.P = json.loads((FROZEN / 'protocol.json').read_text())
            warm.P['workloads'] = [w for w in warm.P['workloads'] if w['id'] == 'json']
            warm.P['warmup_window_seconds'] = 15
            warm.P['warmup_minimum_seconds'] = 135 if case == 'spring-mvc' else 45
            warm.P['warmup_maximum_seconds'] = 360 if case == 'spring-mvc' else 180
            warm.P['warmup_cv_limit'] = .05
            warmed = warm.warmup(loader, output, prefix)
            manifest['warmups'][prefix] = warmed
            save(output / 'manifest.json', manifest)
            if not warmed['stable']:
                manifest['warmup_failures'].append({**job, 'result': warmed})
                stop_server(prefix)
                if job['attempt'] < 3:
                    queue.append({**job, 'attempt': job['attempt'] + 1})
                    phase(job, 'warmup-retry-queued')
                else:
                    phase(job, 'warmup-exhausted')
                continue
            modes = [('closed', None), ('fixed', 20000)]
            if case in ['spine', 'spring-mvc']:
                modes.append(('fixed', 118000))
            offset = (job['round'] - 1) % len(modes)
            modes = modes[offset:] + modes[:offset]
            for mode, target in modes:
                measure(job, prefix, mode, target)
            stop_server(prefix)
            assert not manifest['server_states'][prefix]['State']['OOMKilled']
            completed.add((job['round'], case))
            phase(job, 'server-completed', completed_starts=len(completed), samples=len(manifest['rows']))
        manifest['state'] = 'completed' if len(completed) == 12 and len(manifest['rows']) == 30 else 'incomplete'
        manifest.pop('active', None)
    except BaseException as error:
        manifest.update(state='failed', error=str(error), error_type=type(error).__name__)
        raise
    finally:
        stop_server(prefix)
        if loader:
            command(['docker', 'rm', '-f', loader], check=False)
        manifest['cleanup_completed'] = not command(['docker', 'ps', '--filter', f'name=fourway-{run_id}', '-q']).stdout.strip()
        manifest.update(ended_at=now(), updated_at=now())
        save(output / 'manifest.json', manifest)
        print(json.dumps({'stage': manifest['state'], 'samples': len(manifest['rows']), 'output': str(output)}), flush=True)


if __name__ == '__main__':
    main()
