"""표준 라이브러리만 사용하는 교차 프레임워크 HTTP 계약 검사."""
import http.client
import json
import time

def request(host, port, method, path, body=None):
    conn = http.client.HTTPConnection(host, port, timeout=5)
    try:
        headers = {"Accept-Encoding": "identity"}
        if body is not None:
            headers["Content-Type"] = "application/json"
        conn.request(method, path, body=body, headers=headers)
        response = conn.getresponse()
        return response.status, response.getheader("Content-Type", ""), response.read().decode()
    finally:
        conn.close()


def check_http(host="127.0.0.1", port=3000):
    for _ in range(120):
        try:
            if request(host, port, "GET", "/")[0] == 200:
                break
        except (OSError, http.client.HTTPException):
            pass
        time.sleep(.5)
    else:
        raise RuntimeError("서버 준비 시간 초과")
    checks = []
    for path, expected in [("/", ""), ("/user/00000042", "00000042"), ("/user/abc-123", "abc-123")]:
        status, kind, body = request(host, port, "GET", path)
        if status != 200 or body != expected or kind.lower().replace(" ", "") != "text/plain;charset=utf-8":
            raise RuntimeError(f"문자열 계약 불일치: {path}: {status}, {kind}, {body!r}")
        checks.append({"method": "GET", "path": path, "passed": True})
    valid = [{"id": 42, "name": "benchmark", "active": True},
             {"id": 1, "name": "가", "active": False},
             {"id": 1000000, "name": "a" * 64, "active": True}]
    for value in valid:
        status, kind, body = request(host, port, "POST", "/json", json.dumps(value))
        if status != 200 or not kind.startswith("application/json") or json.loads(body) != value:
            raise RuntimeError(f"JSON 정상 입력 계약 불일치: {status}, {kind}, {body!r}")
        checks.append({"method": "POST", "path": "/json", "input": value, "passed": True})
    sample = valid[0]
    invalid = [sample | {"id": 0}, sample | {"id": 1000001}, sample | {"name": ""},
               sample | {"name": "a" * 65}, {k: v for k, v in sample.items() if k != "active"},
               sample | {"active": None}, sample | {"id": "not-an-integer"}]
    for value in invalid:
        status, _, _ = request(host, port, "POST", "/json", json.dumps(value))
        if status != 400:
            raise RuntimeError(f"JSON 비정상 입력 계약 불일치: {status}, {value!r}")
        checks.append({"method": "POST", "path": "/json", "input": value, "expected_status": 400, "passed": True})
    if request(host, port, "POST", "/json", "{broken")[0] != 400:
        raise RuntimeError("잘못된 JSON 구문이 거부되지 않았습니다.")
    checks.append({"method": "POST", "path": "/json", "input": "{broken", "expected_status": 400, "passed": True})
    return checks



if __name__ == "__main__":
    print(json.dumps(check_http(),ensure_ascii=False))
