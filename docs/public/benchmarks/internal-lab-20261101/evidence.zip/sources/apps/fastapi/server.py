from fastapi import FastAPI
from fastapi.exceptions import RequestValidationError
from fastapi.responses import Response, JSONResponse
from pydantic import BaseModel, ConfigDict, Field

app=FastAPI()
class Input(BaseModel):
    model_config=ConfigDict(strict=True,extra="ignore")
    id:int=Field(ge=1,le=1000000)
    name:str=Field(min_length=1,max_length=64)
    active:bool

@app.exception_handler(RequestValidationError)
async def invalid(request,exception):
    return JSONResponse({"message":"invalid input"},status_code=400)

@app.get("/",response_class=Response)
async def index():
    return Response("",media_type="text/plain")

@app.get("/user/{id}",response_class=Response)
async def user(id:str):
    return Response(id,media_type="text/plain")

@app.post("/json",response_class=JSONResponse)
async def json_body(input:Input):
    return JSONResponse({"id":input.id,"name":input.name,"active":input.active})
