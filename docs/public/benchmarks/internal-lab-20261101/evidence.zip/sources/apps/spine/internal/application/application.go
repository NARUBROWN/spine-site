package application

import (
	"github.com/NARUBROWN/spine"
	"github.com/NARUBROWN/spine/pkg/boot"
	"github.com/NARUBROWN/spine/pkg/httperr"
	"github.com/NARUBROWN/spine/pkg/httpx"
	"github.com/NARUBROWN/spine/pkg/path"
	"unicode/utf8"
)

type Input struct {
	ID     int    `json:"id"`
	Name   string `json:"name"`
	Active *bool  `json:"active"`
}

type BenchmarkController struct{}

func NewBenchmarkController() *BenchmarkController { return &BenchmarkController{} }
func (*BenchmarkController) Index() httpx.Response[string] {
	return httpx.Response[string]{Body: ""}
}
func (*BenchmarkController) User(id path.String) httpx.Response[string] {
	return httpx.Response[string]{Body: id.Value}
}
func (*BenchmarkController) JSON(input *Input) (httpx.Response[Input], error) {
	// Spine의 DTO 바인딩 뒤에 다른 구현과 같은 필드 제약을 명시적으로 검사합니다.
	length := utf8.RuneCountInString(input.Name)
	if input.ID < 1 || input.ID > 1000000 || length < 1 || length > 64 || input.Active == nil {
		return httpx.Response[Input]{}, httperr.BadRequest("invalid input")
	}
	return httpx.Response[Input]{Body: *input}, nil
}

// BuildApplication은 실제 Spine 생성자, 라우팅, 인자 해석과 응답 파이프라인을 사용합니다.
func BuildApplication() (spine.App, boot.Options, error) {
	app := spine.New()
	app.Constructor(NewBenchmarkController)
	app.Route("GET", "/", (*BenchmarkController).Index)
	app.Route("GET", "/user/:id", (*BenchmarkController).User)
	app.Route("POST", "/json", (*BenchmarkController).JSON)
	return app, boot.Options{Address: ":3000", HTTP: &boot.HTTPOptions{}}, nil
}
