# Spine 비교 앱

공개 Spine 0.5.2의 생성자·라우팅·DTO 바인딩·응답 파이프라인을 사용합니다.
GET /, GET /user/:id, POST /json의 비교 계약과 실행 방법은 ../../README.md를 참고하세요.
