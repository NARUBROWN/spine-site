package comparison;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

@RestController
public class BenchmarkController {
 public record Input(@NotNull @Min(1) @Max(1000000) Integer id,@NotNull @Size(min=1,max=64) String name,@NotNull Boolean active) {}
 @GetMapping(value="/",produces="text/plain;charset=UTF-8")
 public String index() { return ""; }
 @GetMapping(value="/user/{id}",produces="text/plain;charset=UTF-8")
 public String user(@PathVariable String id) { return id; }
 @PostMapping(value="/json",consumes="application/json",produces="application/json")
 public Input json(@Valid @RequestBody Input input) { return input; }
}
