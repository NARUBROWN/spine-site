import 'reflect-metadata';
import cluster from 'node:cluster';
import { Controller, Get, Post, Param, Body, Header, HttpCode, Module, ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { ExpressAdapter } from '@nestjs/platform-express';
import { FastifyAdapter } from '@nestjs/platform-fastify';
import { NodeAdapter } from '@nestjs/platform-node';
import { IsInt, Min, Max, IsString, Length, IsBoolean } from 'class-validator';

class Input {
 @IsInt() @Min(1) @Max(1000000) id!: number;
 @IsString() @Length(1,64) name!: string;
 @IsBoolean() active!: boolean;
}
@Controller()
class BenchmarkController {
 @Get('/') @Header('Content-Type','text/plain; charset=utf-8')
 index(): string { return ''; }
 @Get('/user/:id') @Header('Content-Type','text/plain; charset=utf-8')
 user(@Param('id') id: string): string { return id; }
 @Post('/json') @HttpCode(200)
 json(@Body() input: Input) { return {id:input.id,name:input.name,active:input.active}; }
}
@Module({controllers:[BenchmarkController]})
class AppModule {}
async function serve() {
 const selected=process.env.ADAPTER;
 const adapter=selected==='fastify' ? new FastifyAdapter({logger:false,bodyLimit:32*1024*1024,keepAliveTimeout:120000,requestTimeout:30000,maxParamLength:256}) : selected==='node' ? new NodeAdapter() : new ExpressAdapter();
 const app=await NestFactory.create(AppModule,adapter,{logger:false});
 app.useGlobalPipes(new ValidationPipe({transform:false,whitelist:true,forbidUnknownValues:true}));
 const server=app.getHttpServer();
 server.keepAliveTimeout=120000;
 server.headersTimeout=5000;
 server.requestTimeout=30000;
 await app.listen(3000,'0.0.0.0');
}
// 모든 구현에 같은 CPU 예산을 주고 Node에는 세 개의 워커를 허용합니다.
if (cluster.isPrimary) {
 for(let i=0;i<3;i++) cluster.fork();
 cluster.on('exit',()=>process.exit(1));
} else { void serve().catch(e=>{console.error(e);process.exit(1);}); }
