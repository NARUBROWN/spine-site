FROM python:3.15-slim-trixie@sha256:94d3426f1def7db4a106a232ac121bfd975393e5dfd40a619b955fae45fe7913
COPY scripts/zrk /usr/local/bin/zrk
COPY payload.json /opt/payload.json
COPY scripts/http_contract.py /opt/
RUN chmod 755 /usr/local/bin/zrk && zrk --version
ENTRYPOINT ["sleep","infinity"]
